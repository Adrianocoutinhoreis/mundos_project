# FGI Learning Platform — Documentação

Especificações originais do produto estão em `../MD/`:

- `visao_geral.md` — visão do produto, portais, perfis de apoio
- `system_states.md` — estados e fluxos (professor, aluno, jogo, perfil adaptativo)
- `arquitetura.md` — arquitetura de pastas e regras arquiteturais
- `pontuacao.md` — sistema de pontuação, estrelas e níveis de proficiência

## Regras arquiteturais (resumo)

- O professor não conhece os jogos internamente.
- Os jogos não conhecem o professor nem os alunos.
- Os jogos recebem apenas configurações adaptativas e retornam apenas resultados.
- Configurações pertencem ao perfil; perfis pertencem aos alunos; jogos pertencem ao FGI; resultados pertencem ao histórico do aluno.
