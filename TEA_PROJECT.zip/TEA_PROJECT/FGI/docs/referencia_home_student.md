# Referência de Design e Estrutura — Portal do Aluno (Home)

Este documento resume as especificações visuais, paleta de cores (Tailwind) e a estrutura de componentes extraídos do protótipo de referência em HTML do portal do aluno ([referencia_home_student.txt](file:///c:/Users/ricoa/OneDrive/Desktop/TEA_PROJECT/FGI/docs/referencia_home_student.txt)).

---

## 1. Tipografia e Ícones

*   **Fonte Principal**: `Atkinson Hyperlegible Next` (Google Fonts, pesos `400`, `600`, `700`). Essa fonte é projetada especificamente para alta legibilidade e acessibilidade de leitura.
*   **Pacote de Ícones**: `Material Symbols Outlined` (Google Fonts).

---

## 2. Sistema de Design (Configuração do Tailwind)

Abaixo estão os tokens de design utilizados nas classes de estilo do protótipo:

### 2.1. Paleta de Cores (Design System)
As cores são baseadas nas especificações de acessibilidade e tons pastéis para neurodiversidade:

| Token | Cor Hexadecimal | Descrição/Uso |
| :--- | :--- | :--- |
| `primary` | `#006184` | Azul primário principal |
| `primary-container` | `#007ba7` | Fundo de botões e seleções em destaque |
| `on-primary` | `#ffffff` | Texto sobre botões primários |
| `secondary` | `#0c6780` | Azul secundário para elementos de apoio |
| `secondary-container` | `#9ae1ff` | Fundo do avatar ou destaque secundário |
| `on-secondary-container` | `#09657f` | Texto sobre o container secundário |
| `tertiary` | `#485b7a` | Cor neutra fria terciária |
| `background` | `#f7f9fc` | Fundo principal da página (azul-gelo) |
| `surface` | `#f7f9fc` | Fundo de blocos gerais |
| `surface-container-lowest`| `#ffffff` | Fundo branco puro para cartões em destaque |
| `surface-container-low` | `#f2f4f7` | Fundo de painéis e barras laterais |
| `surface-container-high` | `#e6e8eb` | Divisórias e bordas secundárias |
| `outline` | `#6f787f` | Contornos gerais |

### 2.2. Bordas (`borderRadius`)
*   `DEFAULT`: `1rem` (16px) — Arredondamento padrão para cartões e botões.
*   `lg`: `2rem` (32px) — Arredondamento para banners principais.
*   `xl`: `3rem` (48px) — Arredondamento para imagens e blocos grandes.
*   `full`: `9999px` — Formato circular (avatares/botões pílula).

### 2.3. Espaçamento (`spacing`)
*   `section-gap`: `64px` — Espaço entre seções principais.
*   `container-padding`: `32px` — Preenchimento interno das telas.
*   `gutter`: `24px` — Espaço de grade entre cartões.
*   `stack-gap`: `16px` — Distância entre elementos internos empilhados.

### 2.4. Escala de Fontes
*   `display-lg`: `48px` (Line-height: 60px, Weight: 700)
*   `headline-lg`: `32px` (Line-height: 40px, Weight: 700)
*   `headline-md`: `24px` (Line-height: 32px, Weight: 600)
*   `body-lg`: `20px` (Line-height: 30px, Weight: 500)
*   `body-md`: `18px` (Line-height: 28px, Weight: 400)
*   `label-lg`: `16px` (Line-height: 20px, Weight: 600)

---

## 3. Estrutura de Componentes da Página

O portal é composto por cinco áreas organizadas de forma responsiva:

### 3.1. Barra de Navegação Superior (TopAppBar)
*   Fixada no topo (`fixed top-0`).
*   Barra transparente/branca com borda inferior fina de `#e6e8eb`.
*   Contém links rápidos, botão de perfil do usuário (`account_circle`) e botão para deslogar/sair.

### 3.2. Barra Lateral de Navegação (SideNavBar)
*   Exibida apenas em telas desktop (`hidden lg:flex`).
*   Largura fixa de `288px` (`w-72`).
*   Exibe o avatar do mascote ("CollaBoo"), saudação personalizada ("Olá, amigo!"), botão de início rápido ("Começar Meta Diária" com ícone de foguete) e links para a jornada do aluno e configurações.

### 3.3. Painel Central (Main Content)
Ocupa o espaço à direita da barra lateral (`lg:ml-72`). É composto pelas seguintes seções:

*   **Seção de Boas-Vindas (Hero Greeting)**:
    *   Título de boas-vindas destacado: `Olá, Lucas!` (`56px`).
    *   Texto de apoio sobre o dia e atividades.
*   **Card de Progresso (Progress Bento)**:
    *   Card principal com o título "Meu Progresso".
    *   Exibição do número de estrelas acumuladas (ex: `12` estrelas).
    *   Barra de progresso horizontal (`h-6`) mostrando a porcentagem da Meta Diária (ex: `80%`) com preenchimento animado em azul.
*   **Grade de Jogos (Games Grid)**:
    *   Visualização de jogos em formato de cartões interativos.
    *   Cada jogo possui um círculo colorido com o ícone centralizado, título (ex: "Quebra-Cabeça", "Jogo da Memória", "Desenhar"), descrição das ações e um botão "Jogar" na base que assume a cor do jogo no hover.

### 3.4. Barra de Navegação Inferior Mobile (Mobile Navigation Bar)
*   Exibida apenas em dispositivos móveis (`md:hidden`).
*   Menu inferior fixado na tela (`fixed bottom-0`).
*   Contém botões rápidos para a tela inicial, a jornada e um botão flutuante centralizado com ícone de foguete (`rocket_launch`) para metas rápidas.
