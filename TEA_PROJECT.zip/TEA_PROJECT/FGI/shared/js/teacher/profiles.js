(function () {
  async function fetchProfile(id) {
    const res = await fetch('../profiles/' + id + '.json');
    return res.json();
  }

  async function render() {
    const app = document.getElementById('app');
    app.innerHTML =
      TeacherNav.render('profiles') +
      '<main class="layout">' +
      '<h1>Perfis de Apoio</h1>' +
      '<p>Selecione um perfil para configurar os jogos disponíveis.</p>' +
      '<div class="grid cols-2" id="profiles-grid">Carregando...</div>' +
      '</main>';

    const profiles = await Promise.all(window.PROFILE_CATALOG_IDS.map(fetchProfile));
    const grid = document.getElementById('profiles-grid');
    grid.innerHTML = profiles
      .map(
        (p) =>
          '<a class="profile-card" href="games.html?perfil=' +
          p.id +
          '"><div class="card"><h3>' +
          p.nome +
          '</h3><p>' +
          p.descricao +
          '</p></div></a>'
      )
      .join('');
  }

  document.addEventListener('DOMContentLoaded', render);
})();
