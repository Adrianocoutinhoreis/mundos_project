(function () {
  // Tela "Perfil de Apoio" (gerenciador unificado). Duas abas:
  //  - Configuração do Perfil: header do perfil selecionado + seletor + parâmetros
  //    (Visual/Áudio/Cognitivo) + jogos habilitados (busca/filtros/lista agrupada).
  //  - Alunos: cadastro/edição de TODOS os alunos (cada um vinculado a um perfil).

  const profilesById = {};
  const nameById = {};

  const state = {
    tab: 'perfil',
    selectedProfile: (window.PROFILE_CATALOG_IDS || [])[0],
    editingStudentId: null,
    dirty: false,
  };

  // Filtros do card "Jogos do perfil" (persistem ao trocar de perfil).
  const gamesFilter = { q: '', disciplina: null, compatOnly: false, enabledOnly: false };

  // Ícone de "apoio" usado no header do perfil (coração = cuidado/suporte).
  const SUPPORT_ICON =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 1 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>';

  const COR_OPTIONS = [
    { v: 'padrao', l: 'Padrão', color: '#e2e8f0' },
    { v: 'azul', l: 'Azul', color: '#dbeafe' },
    { v: 'lavanda', l: 'Lavanda', color: '#ede9fe' },
    { v: 'pessego', l: 'Pêssego', color: '#ffe0cc' },
    { v: 'amarelo', l: 'Amarelo', color: '#fef3c7' },
  ];

  function byId(id) {
    return document.getElementById(id);
  }

  function fetchProfile(id) {
    return fetch('../profiles/' + id + '.json').then((res) => (res.ok ? res.json() : null));
  }

  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  function studentCount(perfilId) {
    return StorageService.getStudents().filter((s) => s.nivelDeApoio === perfilId).length;
  }

  function corLabel(v) {
    const o = COR_OPTIONS.filter((c) => c.v === v)[0];
    return o ? o.l : 'Padrão';
  }

  // ---------------- Header do perfil selecionado (melhoria 1) ----------------
  function profileHeaderHtml(perfilId) {
    const base = profilesById[perfilId];
    const s = TeacherGameUI.styleFor(perfilId);
    return (
      '<section class="profile-hero" style="--c:' + s.color + '">' +
      '<span class="ph-pic">' + SUPPORT_ICON + '</span>' +
      '<div class="ph-meta"><h2>' + esc(nameById[perfilId]) + '</h2>' +
      '<p>' + esc((base && base.descricao) || '') + '</p></div>' +
      '<div class="ph-stats">' +
      '<div class="ph-stat"><span class="n" id="ph-jogos">' + enabledCount(perfilId) + '</span><span class="l">jogos ativos</span></div>' +
      '<div class="ph-stat"><span class="n">' + studentCount(perfilId) + '</span><span class="l">alunos</span></div>' +
      '</div></section>'
    );
  }

  // ---------------- Seletor de perfil (melhoria 2) ----------------
  function profileSelectorHtml() {
    return (
      '<div class="profile-selector">' +
      window.PROFILE_CATALOG_IDS.map((pid) => {
        const s = TeacherGameUI.styleFor(pid);
        const active = pid === state.selectedProfile;
        return (
          '<button class="profile-chip' + (active ? ' active' : '') + '" type="button" data-profile="' + pid + '" ' +
          'style="--c:' + s.color + (active ? ';border-color:' + s.color : '') + '">' +
          '<span class="chip-dot" style="background:' + s.color + '"></span>' +
          esc(nameById[pid]) +
          '<span class="chip-count">' + studentCount(pid) + '</span>' +
          '</button>'
        );
      }).join('') +
      '</div>'
    );
  }

  // ---------------- Card de configurações (melhorias 3 e 4) ----------------
  function switchRow(id, title, help, checked) {
    return (
      '<div class="cfg-opt"><div class="opt-txt"><div class="opt-title">' + title + '</div>' +
      '<div class="opt-help">' + help + '</div></div>' +
      '<label class="switch"><input type="checkbox" id="' + id + '" ' + (checked ? 'checked' : '') + ' />' +
      '<span class="slider"></span></label></div>'
    );
  }

  function selectRow(id, title, help, options, value) {
    const opts = options
      .map((o) => '<option value="' + o.v + '" ' + (value === o.v ? 'selected' : '') + '>' + o.l + '</option>')
      .join('');
    return (
      '<div class="cfg-opt"><div class="opt-txt"><div class="opt-title">' + title + '</div>' +
      '<div class="opt-help">' + help + '</div></div>' +
      '<select id="' + id + '" class="opt-select">' + opts + '</select></div>'
    );
  }

  function corRow(value) {
    const swatches = COR_OPTIONS.map(
      (o) => '<button type="button" class="cor-swatch' + (value === o.v ? ' sel' : '') + '" data-cor="' + o.v + '" ' +
        'title="' + o.l + '" aria-label="' + o.l + '" style="background:' + o.color + '"></button>'
    ).join('');
    return (
      '<div class="cfg-opt"><div class="opt-txt"><div class="opt-title">Cor de fundo dos jogos</div>' +
      '<div class="opt-help">Aplicada ao fundo das atividades. Selecionada: <b id="cor-current">' + corLabel(value) + '</b></div></div>' +
      '<div class="cor-swatches" id="cor-swatches">' + swatches + '</div></div>'
    );
  }

  function configCardHtml(perfilId) {
    const base = profilesById[perfilId];
    if (!base) return '<div class="card"><p>Perfil não encontrado.</p></div>';
    const config = StorageService.getProfileConfig(perfilId) || {};
    const ajustes = config.ajustes || {};
    const visual = Object.assign({}, base.configuracoes.visual, ajustes.visual);
    const audio = Object.assign({}, base.configuracoes.audio, ajustes.audio);
    const cognitivo = Object.assign({}, base.configuracoes.cognitivo, ajustes.cognitivo);

    return (
      '<form id="params-form" class="card">' +
      '<h2>Configurações</h2>' +

      '<div class="cfg-sec">' +
      '<div class="cfg-sec-head"><span class="si">🎨</span> Visual</div>' +
      switchRow('estimulosReduzidos', 'Reduzir estímulos visuais', 'Menos animações e brilho para diminuir a distração.', visual.estimulosReduzidos) +
      corRow(visual.corFundo || 'padrao') +
      '</div>' +

      '<div class="cfg-sec">' +
      '<div class="cfg-sec-head"><span class="si">🔊</span> Áudio</div>' +
      switchRow('sonsReduzidos', 'Reduzir sons', 'Efeitos sonoros mais suaves e espaçados.', audio.sonsReduzidos) +
      switchRow('mudo', 'Mudo', 'Sem som durante toda a atividade.', audio.mudo) +
      '</div>' +

      '<div class="cfg-sec">' +
      '<div class="cfg-sec-head"><span class="si">🧠</span> Cognitivo</div>' +
      selectRow('feedback', 'Frequência de feedback', 'Com que frequência o jogo confirma acertos.',
        [{ v: 'padrao', l: 'Padrão' }, { v: 'frequente', l: 'Frequente' }, { v: 'constante', l: 'Constante' }], cognitivo.feedback) +
      selectRow('nivelJogo', 'Nível de dificuldade', 'Tamanho das contas apresentadas.',
        [{ v: 'facil', l: 'Fácil (contas pequenas)' }, { v: 'medio', l: 'Médio' }, { v: 'dificil', l: 'Difícil (contas maiores)' }], cognitivo.nivelJogo) +
      switchRow('tempoIlimitado', 'Tempo ilimitado', 'Sem cronômetro; o aluno conclui no seu ritmo.', cognitivo.tempoLimiteSegundos === null) +
      '</div>' +

      '<div class="config-savebar">' +
      '<span class="save-status" id="save-status"><span class="save-dot"></span>Alterações não salvas</span>' +
      '<span class="savebar-actions">' +
      '<button type="button" class="btn secondary btn-sm" id="config-discard">Descartar</button>' +
      '<button type="submit" class="btn btn-sm">Salvar configurações</button>' +
      '</span>' +
      '</div>' +
      '</form>'
    );
  }

  function markDirty(v) {
    state.dirty = v;
    const st = byId('save-status');
    if (st) st.classList.toggle('dirty', v);
  }

  function saveConfig() {
    const sel = document.querySelector('#cor-swatches .cor-swatch.sel');
    const cor = sel ? sel.dataset.cor : 'padrao';
    const ajustes = {
      visual: {
        estimulosReduzidos: byId('estimulosReduzidos').checked,
        corFundo: cor,
      },
      audio: {
        sonsReduzidos: byId('sonsReduzidos').checked,
        mudo: byId('mudo').checked,
      },
      cognitivo: {
        feedback: byId('feedback').value,
        tempoLimiteSegundos: byId('tempoIlimitado').checked ? null : 300,
        nivelJogo: byId('nivelJogo').value,
      },
    };
    StorageService.saveProfileConfig(state.selectedProfile, { ajustes });
    markDirty(false);
    showToast('Configurações salvas para ' + nameById[state.selectedProfile] + '.');
  }

  function renderConfigCard() {
    const slot = byId('config-slot');
    if (slot) {
      slot.innerHTML = configCardHtml(state.selectedProfile);
      bindConfigCard();
    }
  }

  function bindConfigCard() {
    const form = byId('params-form');
    if (!form) return;

    // Qualquer alteração nos campos marca "não salvo" (checkbox/select disparam 'input').
    form.addEventListener('input', () => markDirty(true));

    document.querySelectorAll('#cor-swatches .cor-swatch').forEach((sw) => {
      sw.addEventListener('click', () => {
        document.querySelectorAll('#cor-swatches .cor-swatch').forEach((s) => s.classList.remove('sel'));
        sw.classList.add('sel');
        const cur = byId('cor-current');
        if (cur) cur.textContent = corLabel(sw.dataset.cor);
        markDirty(true);
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      saveConfig();
    });

    byId('config-discard').addEventListener('click', () => {
      renderConfigCard();
      markDirty(false);
    });
  }

  // ---------------- Jogos do perfil (melhorias 5 e 6) ----------------
  function isGameEnabled(perfilId, gameId) {
    const cfg = StorageService.getProfileConfig(perfilId) || {};
    return (cfg.jogosHabilitados || []).indexOf(gameId) !== -1;
  }

  function enabledCount(perfilId) {
    const cfg = StorageService.getProfileConfig(perfilId) || {};
    return (cfg.jogosHabilitados || []).length;
  }

  function setGamesEnabled(perfilId, gameIds, enable) {
    const cfg = StorageService.getProfileConfig(perfilId) || {};
    const set = {};
    (cfg.jogosHabilitados || []).forEach((id) => {
      set[id] = true;
    });
    gameIds.forEach((id) => {
      if (enable) set[id] = true;
      else delete set[id];
    });
    StorageService.saveProfileConfig(perfilId, { jogosHabilitados: Object.keys(set) });
  }

  function disciplinaLabel(id) {
    if (!id) return 'Outros';
    return (window.GAME_DISCIPLINAS && window.GAME_DISCIPLINAS[id]) || (id.charAt(0).toUpperCase() + id.slice(1));
  }

  function uniqueDisciplinas() {
    const seen = [];
    window.GAME_CATALOG.forEach((g) => {
      if (g.disciplina && seen.indexOf(g.disciplina) === -1) seen.push(g.disciplina);
    });
    return seen;
  }

  function filteredGames(perfilId) {
    const q = gamesFilter.q.trim().toLowerCase();
    return window.GAME_CATALOG.filter((g) => {
      if (gamesFilter.disciplina && g.disciplina !== gamesFilter.disciplina) return false;
      if (gamesFilter.compatOnly && (g.perfilCompativel || []).indexOf(perfilId) === -1) return false;
      if (gamesFilter.enabledOnly && !isGameEnabled(perfilId, g.id)) return false;
      if (q) {
        const hay = (g.nomeJogo + ' ' + disciplinaLabel(g.disciplina) + ' ' + (g.habilidades || []).join(' ')).toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function groupKey(g) {
    return g.disciplina || '_outros';
  }

  function jogoRowHtml(perfilId, g) {
    const meta = disciplinaLabel(g.disciplina) + (g.habilidades && g.habilidades.length ? ' · ' + g.habilidades.join(', ') : '');
    const cor = g.cor || '#2563eb';
    const ic = g.icone || '🎮';
    return (
      '<div class="jogo-row" style="--c:' + cor + '">' +
      '<span class="jogo-ic">' + ic + '</span>' +
      '<div class="jogo-row-info"><span class="jogo-name">' + esc(g.nomeJogo) + '</span>' +
      '<span class="jogo-meta">' + esc(meta) + '</span></div>' +
      '<label class="switch"><input type="checkbox" data-game="' + esc(g.id) + '" ' + (isGameEnabled(perfilId, g.id) ? 'checked' : '') + ' />' +
      '<span class="slider"></span></label>' +
      '</div>'
    );
  }

  function jogosListHtml(perfilId) {
    const games = filteredGames(perfilId);
    if (!games.length) return '<p class="jogos-empty">Nenhum jogo encontrado com esses filtros.</p>';

    const groups = {};
    const order = [];
    games.forEach((g) => {
      const key = groupKey(g);
      if (!groups[key]) {
        groups[key] = [];
        order.push(key);
      }
      groups[key].push(g);
    });

    return order
      .map((key) => {
        const rows = groups[key];
        const total = window.GAME_CATALOG.filter((g) => groupKey(g) === key).length;
        const enabledInGroup = window.GAME_CATALOG.filter((g) => groupKey(g) === key && isGameEnabled(perfilId, g.id)).length;
        const allOn = rows.every((g) => isGameEnabled(perfilId, g.id));
        return (
          '<div class="jogo-group">' +
          '<div class="jogo-group-header">' +
          '<span class="jogo-group-title">' + esc(disciplinaLabel(key === '_outros' ? null : key)) +
          ' <span class="jogo-group-count">(' + enabledInGroup + '/' + total + ')</span></span>' +
          '<button class="jogo-group-all" type="button" data-disciplina="' + esc(key) + '">' +
          (allOn ? 'Desabilitar todos' : 'Habilitar todos') + '</button>' +
          '</div>' +
          rows.map((g) => jogoRowHtml(perfilId, g)).join('') +
          '</div>'
        );
      })
      .join('');
  }

  function jogosCardHtml(perfilId) {
    const disciplinaChips = uniqueDisciplinas()
      .map((d) => '<button class="filter-pill" type="button" data-disciplina="' + esc(d) + '">' + esc(disciplinaLabel(d)) + '</button>')
      .join('');

    return (
      '<div class="card" id="jogos-card">' +
      '<div class="jogos-head"><h2>Jogos do perfil</h2><span class="jogos-counter" id="jogos-counter"></span></div>' +
      '<div class="jogos-progress"><span class="bar" id="jogos-progress-bar"></span></div>' +
      '<p class="card-sub">Ative os jogos disponíveis para alunos deste perfil. A adaptação é aplicada automaticamente a partir das configurações ao lado.</p>' +
      '<div class="jogos-search"><span class="search-icon">' + TeacherNav.ICONS.search + '</span>' +
      '<input type="search" id="jogos-search" placeholder="Buscar jogo, disciplina ou habilidade..." aria-label="Buscar jogo" /></div>' +
      '<div class="jogos-filters" id="jogos-filters">' +
      '<button class="filter-pill" type="button" data-filter="compat">Compatíveis com este perfil</button>' +
      '<button class="filter-pill" type="button" data-filter="enabled">Só habilitados</button>' +
      disciplinaChips +
      '</div>' +
      '<div class="jogos-bulk">' +
      '<button class="btn secondary btn-sm" type="button" id="jogos-enable-all">Habilitar filtrados</button>' +
      '<button class="btn secondary btn-sm" type="button" id="jogos-disable-all">Limpar filtrados</button>' +
      '</div>' +
      '<div id="jogos-list">' + jogosListHtml(perfilId) + '</div>' +
      '</div>'
    );
  }

  function updateJogosList() {
    const sp = state.selectedProfile;
    const listEl = byId('jogos-list');
    if (listEl) listEl.innerHTML = jogosListHtml(sp);
    const n = enabledCount(sp);
    const total = window.GAME_CATALOG.length;
    const counter = byId('jogos-counter');
    if (counter) counter.textContent = n + '/' + total + ' habilitados';
    const bar = byId('jogos-progress-bar');
    if (bar) bar.style.width = (total ? Math.round((n / total) * 100) : 0) + '%';
    const ph = byId('ph-jogos');
    if (ph) ph.textContent = n;
  }

  function bindJogosCard() {
    updateJogosList();

    const search = byId('jogos-search');
    if (search) {
      search.value = gamesFilter.q;
      search.addEventListener('input', () => {
        gamesFilter.q = search.value;
        updateJogosList();
      });
    }

    document.querySelectorAll('#jogos-filters .filter-pill').forEach((pill) => {
      if (pill.dataset.filter === 'compat' && gamesFilter.compatOnly) pill.classList.add('active');
      if (pill.dataset.filter === 'enabled' && gamesFilter.enabledOnly) pill.classList.add('active');
      if (pill.dataset.disciplina && gamesFilter.disciplina === pill.dataset.disciplina) pill.classList.add('active');

      pill.addEventListener('click', () => {
        if (pill.dataset.filter === 'compat') {
          gamesFilter.compatOnly = !gamesFilter.compatOnly;
          pill.classList.toggle('active', gamesFilter.compatOnly);
        } else if (pill.dataset.filter === 'enabled') {
          gamesFilter.enabledOnly = !gamesFilter.enabledOnly;
          pill.classList.toggle('active', gamesFilter.enabledOnly);
        } else if (pill.dataset.disciplina) {
          const d = pill.dataset.disciplina;
          gamesFilter.disciplina = gamesFilter.disciplina === d ? null : d;
          document.querySelectorAll('#jogos-filters .filter-pill[data-disciplina]').forEach((p) =>
            p.classList.toggle('active', p.dataset.disciplina === gamesFilter.disciplina)
          );
        }
        updateJogosList();
      });
    });

    byId('jogos-enable-all').addEventListener('click', () => {
      setGamesEnabled(state.selectedProfile, filteredGames(state.selectedProfile).map((g) => g.id), true);
      updateJogosList();
      showToast('Jogos habilitados para ' + nameById[state.selectedProfile] + '.');
    });
    byId('jogos-disable-all').addEventListener('click', () => {
      setGamesEnabled(state.selectedProfile, filteredGames(state.selectedProfile).map((g) => g.id), false);
      updateJogosList();
      showToast('Jogos removidos de ' + nameById[state.selectedProfile] + '.');
    });

    const listEl = byId('jogos-list');
    listEl.addEventListener('change', (e) => {
      const cb = e.target.closest('input[type="checkbox"][data-game]');
      if (!cb) return;
      setGamesEnabled(state.selectedProfile, [cb.dataset.game], cb.checked);
      updateJogosList();
    });
    listEl.addEventListener('click', (e) => {
      const btn = e.target.closest('.jogo-group-all');
      if (!btn) return;
      const key = btn.dataset.disciplina;
      const inGroup = filteredGames(state.selectedProfile).filter((g) => groupKey(g) === key);
      const allOn = inGroup.every((g) => isGameEnabled(state.selectedProfile, g.id));
      setGamesEnabled(state.selectedProfile, inGroup.map((g) => g.id), !allOn);
      updateJogosList();
    });
  }

  // ---------------- Aba Perfil ----------------
  function perfilTabHtml() {
    return (
      profileHeaderHtml(state.selectedProfile) +
      profileSelectorHtml() +
      '<div class="perfil-config-grid">' +
      '<div id="config-slot">' + configCardHtml(state.selectedProfile) + '</div>' +
      '<div id="jogos-slot">' + jogosCardHtml(state.selectedProfile) + '</div>' +
      '</div>'
    );
  }

  function bindPerfilTab() {
    document.querySelectorAll('.profile-chip').forEach((chip) => {
      chip.addEventListener('click', () => {
        state.selectedProfile = chip.dataset.profile;
        state.dirty = false;
        renderTab();
      });
    });
    bindConfigCard();
    bindJogosCard();
  }

  // ---------------- Aba Alunos (inalterada) ----------------
  function studentFormHtml() {
    const student = state.editingStudentId ? StorageService.getStudentById(state.editingStudentId) : null;
    const options = window.PROFILE_CATALOG_IDS.map(
      (pid) => '<option value="' + pid + '" ' + (student && student.nivelDeApoio === pid ? 'selected' : '') + '>' + esc(nameById[pid]) + '</option>'
    ).join('');

    return (
      '<form id="student-form" class="card">' +
      '<h2>' + (student ? 'Editar Aluno' : 'Cadastrar Novo Aluno') + '</h2>' +
      '<input type="hidden" id="student-id" value="' + (student ? esc(student.id) : '') + '" />' +
      '<div class="form-field"><label for="nome">Nome</label><input id="nome" required value="' + (student ? esc(student.nomeAluno) : '') + '" /></div>' +
      '<div class="form-field"><label for="login">Login</label><input id="login" required value="' + (student ? esc(student.login) : '') + '" /></div>' +
      '<div class="form-field"><label for="senha">Senha</label><input id="senha" required value="' + (student ? esc(student.senha) : '') + '" /></div>' +
      '<div class="form-field"><label for="perfilId">Perfil de Apoio</label><select id="perfilId">' + options + '</select></div>' +
      '<div style="display:flex; gap:12px;">' +
      '<button type="submit" class="btn">' + (student ? 'Salvar Alterações' : 'Cadastrar Aluno') + '</button>' +
      (student ? '<button type="button" class="btn secondary" id="cancel-edit">Cancelar</button>' : '') +
      '</div>' +
      '</form>'
    );
  }

  function studentsTableHtml() {
    const students = StorageService.getStudents();
    if (!students.length) return '<div class="card"><p>Nenhum aluno cadastrado ainda.</p></div>';
    const rows = students
      .map(
        (s) =>
          '<tr>' +
          '<td>' + esc(s.nomeAluno) + '</td>' +
          '<td>' + esc(s.login) + '</td>' +
          '<td>' + esc(nameById[s.nivelDeApoio] || s.nivelDeApoio) + '</td>' +
          '<td style="display:flex; gap:8px;">' +
          '<button class="btn secondary" data-edit="' + esc(s.id) + '" type="button">Editar</button>' +
          '<button class="btn danger" data-delete="' + esc(s.id) + '" type="button">Remover</button>' +
          '</td>' +
          '</tr>'
      )
      .join('');
    return (
      '<table class="reports-table card"><thead><tr><th>Nome</th><th>Login</th><th>Perfil</th><th>Ações</th></tr></thead>' +
      '<tbody>' + rows + '</tbody></table>'
    );
  }

  function alunosTabHtml() {
    return studentFormHtml() + '<div style="margin-top:24px;">' + studentsTableHtml() + '</div>';
  }

  function bindAlunosTab() {
    const form = byId('student-form');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const id = byId('student-id').value;
      const login = byId('login').value.trim().toLowerCase();

      const conflict = StorageService.getStudentByLogin(login);
      if (conflict && conflict.id !== id) {
        showToast('Esse login já está em uso por outro aluno.');
        return;
      }

      const student = {
        nomeAluno: byId('nome').value.trim(),
        login,
        senha: byId('senha').value,
        nivelDeApoio: byId('perfilId').value,
      };
      if (id) student.id = id;

      StorageService.saveStudent(student);
      showToast(id ? 'Aluno atualizado.' : 'Aluno cadastrado.');
      state.editingStudentId = null;
      renderTab();
    });

    const cancelBtn = byId('cancel-edit');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        state.editingStudentId = null;
        renderTab();
      });
    }

    document.querySelectorAll('[data-edit]').forEach((btn) => {
      btn.addEventListener('click', () => {
        state.editingStudentId = btn.dataset.edit;
        renderTab();
        const nome = byId('nome');
        if (nome) nome.focus();
      });
    });

    document.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (confirm('Remover este aluno? O histórico de resultados dele é mantido.')) {
          StorageService.deleteStudent(btn.dataset.delete);
          renderTab();
        }
      });
    });
  }

  // ---------------- Estrutura / abas (melhoria 7) ----------------
  function tabBtn(id, label, count) {
    return (
      '<button class="tab-btn' + (state.tab === id ? ' active' : '') + '" type="button" data-tab="' + id + '">' +
      label +
      (count != null ? ' <span class="tab-count">' + count + '</span>' : '') +
      '</button>'
    );
  }

  function renderTab() {
    const el = byId('tab-content');
    if (state.tab === 'perfil') {
      el.innerHTML = perfilTabHtml();
      bindPerfilTab();
    } else {
      el.innerHTML = alunosTabHtml();
      bindAlunosTab();
    }
  }

  function bindTabs() {
    document.querySelectorAll('.tabs .tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (state.tab === btn.dataset.tab) return;
        state.tab = btn.dataset.tab;
        if (state.tab !== 'alunos') state.editingStudentId = null;
        state.dirty = false;
        document.querySelectorAll('.tabs .tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === state.tab));
        renderTab();
      });
    });
  }

  async function render() {
    const app = document.getElementById('app');
    app.innerHTML = TeacherNav.render('profiles') + '<main class="layout"><p>Carregando...</p></main>';

    const ids = window.PROFILE_CATALOG_IDS;
    const list = await Promise.all(ids.map(fetchProfile));
    ids.forEach((id, i) => {
      profilesById[id] = list[i];
      nameById[id] = (list[i] && list[i].nomePerfil) || id;
    });
    TeacherGameUI.setProfileNames(nameById);

    const totalAlunos = StorageService.getStudents().length;

    app.innerHTML =
      TeacherNav.render('profiles') +
      '<main class="layout">' +
      '<div class="dash-hero"><h1>Perfil de Apoio</h1>' +
      '<p>Configure cada perfil, defina os jogos disponíveis e gerencie os alunos.</p></div>' +
      '<div class="tabs">' + tabBtn('perfil', 'Configuração do Perfil') + tabBtn('alunos', 'Alunos', totalAlunos) + '</div>' +
      '<div id="tab-content"></div>' +
      '</main>';

    bindTabs();
    renderTab();
  }

  document.addEventListener('DOMContentLoaded', render);
})();
