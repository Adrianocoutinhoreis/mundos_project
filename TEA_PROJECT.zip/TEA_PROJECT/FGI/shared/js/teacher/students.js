(function () {
  async function fetchProfiles() {
    return Promise.all(
      window.PROFILE_CATALOG_IDS.map((id) => fetch('../profiles/' + id + '.json').then((res) => res.json()))
    );
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  function studentFormHtml(profiles, student) {
    const options = profiles
      .map((p) => '<option value="' + p.id + '" ' + (student && student.perfilId === p.id ? 'selected' : '') + '>' + p.nome + '</option>')
      .join('');
    return (
      '<form id="student-form" class="card">' +
      '<h2>' + (student ? 'Editar Aluno' : 'Cadastrar Novo Aluno') + '</h2>' +
      '<input type="hidden" id="student-id" value="' + (student ? student.id : '') + '" />' +
      '<div class="form-field"><label for="nome">Nome</label><input id="nome" required value="' + (student ? student.nome : '') + '" /></div>' +
      '<div class="form-field"><label for="login">Login</label><input id="login" required value="' + (student ? student.login : '') + '" /></div>' +
      '<div class="form-field"><label for="senha">Senha</label><input id="senha" required value="' + (student ? student.senha : '') + '" /></div>' +
      '<div class="form-field"><label for="perfilId">Perfil de Apoio</label><select id="perfilId">' + options + '</select></div>' +
      '<div style="display:flex; gap:12px;">' +
      '<button type="submit" class="btn">' + (student ? 'Salvar Alterações' : 'Cadastrar Aluno') + '</button>' +
      (student ? '<button type="button" class="btn secondary" id="cancel-edit">Cancelar</button>' : '') +
      '</div>' +
      '</form>'
    );
  }

  function studentsTableHtml(students, profileNameById) {
    if (!students.length) {
      return '<div class="card"><p>Nenhum aluno cadastrado ainda.</p></div>';
    }
    const rows = students
      .map(
        (s) =>
          '<tr>' +
          '<td>' + s.nome + '</td>' +
          '<td>' + s.login + '</td>' +
          '<td>' + (profileNameById[s.perfilId] || s.perfilId) + '</td>' +
          '<td style="display:flex; gap:8px;">' +
          '<button class="btn secondary" data-edit="' + s.id + '" type="button">Editar</button>' +
          '<button class="btn danger" data-delete="' + s.id + '" type="button">Remover</button>' +
          '</td>' +
          '</tr>'
      )
      .join('');
    return (
      '<table class="reports-table card">' +
      '<thead><tr><th>Nome</th><th>Login</th><th>Perfil</th><th>Ações</th></tr></thead>' +
      '<tbody>' + rows + '</tbody>' +
      '</table>'
    );
  }

  async function render() {
    const app = document.getElementById('app');
    app.innerHTML = TeacherNav.render('students') + '<main class="layout"><h1>Gerenciar Alunos</h1><p>Carregando...</p></main>';

    const profiles = await fetchProfiles();
    const profileNameById = {};
    profiles.forEach((p) => {
      profileNameById[p.id] = p.nome;
    });

    let editingStudent = null;

    function renderAll() {
      const students = StorageService.getStudents();
      app.innerHTML =
        TeacherNav.render('students') +
        '<main class="layout">' +
        '<h1>Gerenciar Alunos</h1>' +
        '<p>Cadastre alunos e associe cada um a um perfil de apoio. A adaptação do jogo é automática a partir do perfil escolhido — não há ajustes individuais por aluno.</p>' +
        studentFormHtml(profiles, editingStudent) +
        '<div style="margin-top:24px;">' + studentsTableHtml(students, profileNameById) + '</div>' +
        '</main>';
      bindEvents();
    }

    function bindEvents() {
      document.getElementById('student-form').addEventListener('submit', (event) => {
        event.preventDefault();
        const id = document.getElementById('student-id').value;
        const login = document.getElementById('login').value.trim().toLowerCase();

        const conflict = StorageService.getStudentByLogin(login);
        if (conflict && conflict.id !== id) {
          showToast('Esse login já está em uso por outro aluno.');
          return;
        }

        const student = {
          nome: document.getElementById('nome').value.trim(),
          login,
          senha: document.getElementById('senha').value,
          perfilId: document.getElementById('perfilId').value,
        };
        if (id) student.id = id;

        StorageService.saveStudent(student);
        showToast(id ? 'Aluno atualizado.' : 'Aluno cadastrado.');
        editingStudent = null;
        renderAll();
      });

      const cancelBtn = document.getElementById('cancel-edit');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
          editingStudent = null;
          renderAll();
        });
      }

      document.querySelectorAll('[data-edit]').forEach((btn) => {
        btn.addEventListener('click', () => {
          editingStudent = StorageService.getStudentById(btn.dataset.edit);
          renderAll();
          document.getElementById('nome').focus();
        });
      });

      document.querySelectorAll('[data-delete]').forEach((btn) => {
        btn.addEventListener('click', () => {
          if (confirm('Remover este aluno? O histórico de resultados dele é mantido.')) {
            StorageService.deleteStudent(btn.dataset.delete);
            renderAll();
          }
        });
      });
    }

    renderAll();
  }

  document.addEventListener('DOMContentLoaded', render);
})();
