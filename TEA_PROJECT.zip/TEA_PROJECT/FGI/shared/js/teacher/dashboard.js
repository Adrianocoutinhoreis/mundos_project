(function () {
  function statCard(value, label) {
    return (
      '<div class="card stat-card"><div class="stat-value">' +
      value +
      '</div><div class="stat-label">' +
      label +
      '</div></div>'
    );
  }

  function quickLink(href, title, description) {
    return (
      '<a class="profile-card" href="' +
      href +
      '"><div class="card"><h3>' +
      title +
      '</h3><p>' +
      description +
      '</p></div></a>'
    );
  }

  function render() {
    const students = StorageService.getStudents();
    const results = StorageService.getGameResults();
    const perfilCount = window.PROFILE_CATALOG_IDS.length;

    document.getElementById('app').innerHTML =
      TeacherNav.render('dashboard') +
      '<main class="layout">' +
      '<h1>Painel do Professor</h1>' +
      '<p>Gerencie perfis de apoio, disponibilize jogos e acompanhe o progresso dos alunos.</p>' +
      '<div class="grid cols-3">' +
      statCard(perfilCount, 'Perfis de Apoio') +
      statCard(students.length, 'Alunos Cadastrados') +
      statCard(results.length, 'Atividades Concluídas') +
      '</div>' +
      '<div class="grid cols-3" style="margin-top: 32px;">' +
      quickLink('profiles.html', 'Perfis de Apoio', 'Selecionar um perfil e configurar jogos disponíveis.') +
      quickLink('students.html', 'Gerenciar Alunos', 'Cadastrar alunos e associar cada um a um perfil de apoio.') +
      quickLink('reports.html', 'Resultados e Progresso', 'Ver o desempenho dos alunos nas atividades.') +
      '</div>' +
      '</main>';
  }

  document.addEventListener('DOMContentLoaded', render);
})();
