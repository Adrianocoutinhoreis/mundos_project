(function () {
  const ICONS = window.TeacherNav.ICONS;

  const FEATURE_ICON = {
    perfil:
      '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    chart: ICONS.chart,
    gamepad: ICONS.gamepad,
  };

  function fetchJSON(url) {
    return fetch(url).then((res) => (res.ok ? res.json() : null)).catch(() => null);
  }

  function featureCard(href, icon, title, description, linkText, highlight) {
    return (
      '<a class="feature-card' + (highlight ? ' highlight' : '') + '" href="' + href + '">' +
      '<span class="feature-icon">' + FEATURE_ICON[icon] + '</span>' +
      '<h3>' + title + '</h3>' +
      '<p>' + description + '</p>' +
      '<span class="feature-link">' + linkText +
      ' <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>' +
      '</span>' +
      '</a>'
    );
  }

  async function render() {
    const app = document.getElementById('app');
    app.innerHTML =
      TeacherNav.render('dashboard', { search: true, searchId: 'dash-search' }) +
      '<main class="layout"><p>Carregando painel...</p></main>';

    // Nomes legíveis dos perfis (para tags e modal de jogar).
    const ids = window.PROFILE_CATALOG_IDS;
    const profiles = await Promise.all(ids.map((id) => fetchJSON('../profiles/' + id + '.json')));
    const nameById = {};
    ids.forEach((id, i) => {
      nameById[id] = (profiles[i] && profiles[i].nomePerfil) || id;
    });
    TeacherGameUI.setProfileNames(nameById);

    const manifests = await Promise.all(
      window.GAME_CATALOG.map((g) => fetchJSON('../games/' + g.id + '/manifest.json'))
    );
    const gameCardsHtml = window.GAME_CATALOG.map((g, i) =>
      TeacherGameUI.renderGameCard(g, manifests[i], { showTags: true, tagsRemovable: false })
    ).join('');

    const main =
      '<main class="layout">' +
      '<div class="dash-hero">' +
      '<h1>Painel do Professor</h1>' +
      '<p>Gerencie seus perfis, alunos e acompanhe o progresso em tempo real.</p>' +
      '</div>' +

      '<div class="feature-grid">' +
      featureCard('profiles.html', 'perfil', 'Perfil de Apoio', 'Configurar perfis de apoio, jogos habilitados e gerenciar os alunos.', 'Acessar', false) +
      featureCard('reports.html', 'chart', 'Resultados e Progresso', 'Relatórios de desempenho e métricas individuais dos alunos.', 'Ver Gráficos', false) +
      featureCard('games.html', 'gamepad', 'Jogos Disponíveis', 'Explore o catálogo pedagógico completo de atividades.', 'Explorar Agora', true) +
      '</div>' +

      '<section class="games-section" id="jogos">' +
      '<h2>Novos Jogos</h2>' +
      '<p class="section-sub">Selecione um Jogo para iniciar com seus alunos.</p>' +
      '<div class="games-grid" id="games-grid">' + gameCardsHtml + '</div>' +
      '</section>' +
      '</main>';

    app.innerHTML = TeacherNav.render('dashboard', { search: true, searchId: 'dash-search' }) + main;

    const grid = document.getElementById('games-grid');
    TeacherGameUI.bindContainer(grid, { onChange: applySearch });

    function applySearch() {
      const input = document.getElementById('dash-search');
      const q = (input && input.value ? input.value : '').trim().toLowerCase();
      grid.querySelectorAll('.game-card').forEach((card) => {
        const match = !q || (card.dataset.search || '').indexOf(q) !== -1;
        card.style.display = match ? '' : 'none';
      });
    }

    const searchInput = document.getElementById('dash-search');
    if (searchInput) searchInput.addEventListener('input', applySearch);
  }

  document.addEventListener('DOMContentLoaded', render);
})();
