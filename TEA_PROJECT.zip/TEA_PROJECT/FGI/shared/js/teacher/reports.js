(function () {
  async function fetchProfileNameById() {
    const profiles = await Promise.all(
      window.PROFILE_CATALOG_IDS.map((id) => fetch('../profiles/' + id + '.json').then((res) => res.json()))
    );
    const nameById = {};
    profiles.forEach((p) => {
      nameById[p.id] = p.nome;
    });
    return nameById;
  }

  function calcularProficiencia(studentResults) {
    if (!studentResults.length) {
      return { texto: 'Sem dados', className: 'badge-neutral', titulo: '' };
    }
    const media = studentResults.reduce((soma, r) => soma + (r.pontuacao || 0), 0) / studentResults.length;
    if (media >= 80) return { texto: 'Acima', className: 'badge-success', titulo: 'Proficiente' };
    if (media >= 50) return { texto: 'No Nível', className: 'badge-warning', titulo: 'Inicial' };
    return { texto: 'Abaixo', className: 'badge-danger', titulo: 'Familiar' };
  }

  async function render() {
    const students = StorageService.getStudents();
    const results = StorageService.getGameResults();
    const profileNameById = await fetchProfileNameById();

    const rows = students
      .map((student) => {
        const studentResults = results.filter((r) => r.studentId === student.id);
        const ultimo = studentResults[studentResults.length - 1];
        const proficiencia = calcularProficiencia(studentResults);
        const jsonDump = JSON.stringify(studentResults, null, 2).replace(/</g, '&lt;');
        return (
          '<tr>' +
          '<td>' + student.nome + '</td>' +
          '<td>' + (profileNameById[student.perfilId] || student.perfilId) + '</td>' +
          '<td>' + studentResults.length + '</td>' +
          '<td>' + (ultimo ? new Date(ultimo.concluidoEm).toLocaleString('pt-BR') : '—') + '</td>' +
          '<td><span class="badge ' + proficiencia.className + '" title="' + proficiencia.titulo + '">' + proficiencia.texto + '</span></td>' +
          '<td><button type="button" class="btn secondary json-toggle" data-student-id="' + student.id + '">Ver JSON</button></td>' +
          '</tr>' +
          '<tr class="json-row" data-student-id="' + student.id + '" hidden>' +
          '<td colspan="6"><pre class="json-dump">' + jsonDump + '</pre></td>' +
          '</tr>'
        );
      })
      .join('');

    document.getElementById('app').innerHTML =
      TeacherNav.render('reports') +
      '<main class="layout">' +
      '<h1>Resultados e Progresso</h1>' +
      '<table class="reports-table card">' +
      '<thead><tr><th>Aluno</th><th>Perfil</th><th>Atividades Concluídas</th><th>Última Atividade</th><th>Nível de Proficiência</th><th>Dev</th></tr></thead>' +
      '<tbody>' + rows + '</tbody>' +
      '</table>' +
      '</main>';

    document.querySelector('.reports-table tbody').addEventListener('click', (event) => {
      const button = event.target.closest('.json-toggle');
      if (!button) return;
      const jsonRow = document.querySelector('.json-row[data-student-id="' + button.dataset.studentId + '"]');
      jsonRow.toggleAttribute('hidden');
      button.textContent = jsonRow.hidden ? 'Ver JSON' : 'Ocultar JSON';
    });
  }

  document.addEventListener('DOMContentLoaded', render);
})();
