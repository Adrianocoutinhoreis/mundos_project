(function () {
  async function fetchProfileNameById() {
    const profiles = await Promise.all(
      window.PROFILE_CATALOG_IDS.map((id) => fetch('../profiles/' + id + '.json').then((res) => res.json()))
    );
    const nameById = {};
    profiles.forEach((p) => {
      nameById[p.id] = p.nomePerfil;
    });
    return nameById;
  }

  function calcularProficiencia(studentResults) {
    if (!studentResults.length) {
      return { texto: 'Sem dados', className: 'badge-neutral', titulo: '' };
    }
    const media = studentResults.reduce((soma, r) => soma + (r.pontuacao || 0), 0) / studentResults.length;
    // Mesmas faixas usadas nas estrelas/pontos do aluno (fonte única: gamification.js).
    return Gamification.proficienciaPorMedia(media);
  }

  function esc(valor) {
    return String(valor == null ? '' : valor)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/"/g, '&quot;');
  }

  function statusBadge(r) {
    return r.enviado
      ? '<span class="badge badge-success" title="Enviado para a plataforma">✅ Enviado</span>'
      : '<span class="badge badge-neutral" title="Ainda não sincronizado">⏳ Pendente</span>';
  }

  // Uma linha POR execução (substitui o antigo despejo do array inteiro). Cada
  // execução pode abrir seu próprio JSON — um objeto por vez, nunca o histórico.
  function execucaoRow(r) {
    const quando = r.concluidoEm ? new Date(r.concluidoEm).toLocaleString('pt-BR') : '—';
    const jsonUm = esc(JSON.stringify(r, null, 2));
    return (
      '<tr>' +
      '<td>' + quando + '</td>' +
      '<td>' + esc(r.jogoId || '—') + '</td>' +
      '<td>' + (r.pontuacao != null ? r.pontuacao : '—') + '</td>' +
      '<td>' + statusBadge(r) + '</td>' +
      '<td><button type="button" class="btn secondary json-toggle-exec" data-res-id="' + esc(r.id) + '">Ver JSON</button></td>' +
      '</tr>' +
      '<tr class="json-row-exec" data-res-id="' + esc(r.id) + '" hidden>' +
      '<td colspan="5"><pre class="json-dump">' + jsonUm + '</pre></td>' +
      '</tr>'
    );
  }

  async function render() {
    const students = StorageService.getStudents();
    const results = StorageService.getGameResults();
    const profileNameById = await fetchProfileNameById();

    const integracaoAtiva = window.EducandusSync && EducandusSync.estaConfigurado();
    const pendentesTotal = results.filter((r) => !r.enviado).length;

    const rows = students
      .map((student) => {
        const studentResults = results.filter((r) => r.alunoId === student.id);
        const ultimo = studentResults[studentResults.length - 1];
        const proficiencia = calcularProficiencia(studentResults);
        const pendentesAluno = studentResults.filter((r) => !r.enviado).length;

        // Execuções mais recentes primeiro.
        const execRows = studentResults.length
          ? studentResults.slice().reverse().map(execucaoRow).join('')
          : '<tr><td colspan="5">Nenhuma atividade concluída.</td></tr>';

        return (
          '<tr>' +
          '<td>' + esc(student.nomeAluno) + '</td>' +
          '<td>' + esc(profileNameById[student.nivelDeApoio] || student.nivelDeApoio) + '</td>' +
          '<td>' + studentResults.length + '</td>' +
          '<td>' + (ultimo ? new Date(ultimo.concluidoEm).toLocaleString('pt-BR') : '—') + '</td>' +
          '<td><span class="badge ' + proficiencia.className + '" title="' + esc(proficiencia.titulo) + '">' + proficiencia.texto + '</span></td>' +
          '<td>' + (pendentesAluno ? '<span class="badge badge-neutral">⏳ ' + pendentesAluno + '</span>' : (studentResults.length ? '<span class="badge badge-success">✅</span>' : '—')) + '</td>' +
          '<td><button type="button" class="btn secondary detalhe-toggle" data-aluno-id="' + esc(student.id) + '">Ver execuções</button></td>' +
          '</tr>' +
          '<tr class="detalhe-row" data-aluno-id="' + esc(student.id) + '" hidden>' +
          '<td colspan="7">' +
          '<table class="exec-table">' +
          '<thead><tr><th>Quando</th><th>Jogo</th><th>Pontuação</th><th>Envio</th><th>Dev</th></tr></thead>' +
          '<tbody>' + execRows + '</tbody>' +
          '</table>' +
          '</td>' +
          '</tr>'
        );
      })
      .join('');

    const syncBar = integracaoAtiva
      ? '<p class="sync-bar">Integração ativa. Pendentes de envio: <strong id="pendentes-count">' + pendentesTotal + '</strong> ' +
        '<button type="button" class="btn" id="reenviar-btn"' + (pendentesTotal ? '' : ' disabled') + '>Reenviar pendentes</button></p>'
      : '<p class="sync-bar">Integração não configurada — os resultados ficam apenas neste dispositivo. ' +
        'Configure a URL em <a href="settings.html">Configurações</a>.</p>';

    document.getElementById('app').innerHTML =
      TeacherNav.render('reports') +
      '<main class="layout">' +
      '<h1>Resultados e Progresso</h1>' +
      syncBar +
      '<table class="reports-table card">' +
      '<thead><tr><th>Aluno</th><th>Perfil</th><th>Atividades</th><th>Última Atividade</th><th>Proficiência</th><th>Envio</th><th>Detalhes</th></tr></thead>' +
      '<tbody>' + rows + '</tbody>' +
      '</table>' +
      '</main>';

    document.querySelector('.reports-table tbody').addEventListener('click', (event) => {
      const btnAluno = event.target.closest('.detalhe-toggle');
      if (btnAluno) {
        const row = document.querySelector('.detalhe-row[data-aluno-id="' + btnAluno.dataset.alunoId + '"]');
        row.toggleAttribute('hidden');
        btnAluno.textContent = row.hidden ? 'Ver execuções' : 'Ocultar execuções';
        return;
      }
      const btnExec = event.target.closest('.json-toggle-exec');
      if (btnExec) {
        const row = document.querySelector('.json-row-exec[data-res-id="' + btnExec.dataset.resId + '"]');
        row.toggleAttribute('hidden');
        btnExec.textContent = row.hidden ? 'Ver JSON' : 'Ocultar JSON';
      }
    });

    const reenviarBtn = document.getElementById('reenviar-btn');
    if (reenviarBtn) {
      reenviarBtn.addEventListener('click', async () => {
        reenviarBtn.disabled = true;
        reenviarBtn.textContent = 'Enviando...';
        const resumo = await EducandusSync.sincronizarPendentes();
        await render(); // re-renderiza com o status atualizado
        showToast('Reenvio concluído: ' + resumo.enviados + ' de ' + resumo.total + ' enviado(s).');
      });
    }
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  document.addEventListener('DOMContentLoaded', render);
})();
