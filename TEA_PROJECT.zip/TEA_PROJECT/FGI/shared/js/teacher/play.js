(function () {
  // Modo TESTE do professor: abre um jogo com a configuração de um perfil de apoio,
  // sem sessão de aluno e SEM gravar resultado. Reaproveita o mesmo contrato do jogo
  // (iframe com ?config=<configuracoes em JSON>) usado pela tela do aluno.

  function getParams() {
    const q = new URLSearchParams(window.location.search);
    return { jogo: q.get('jogo'), perfil: q.get('perfil') };
  }

  function fetchJSON(url) {
    return fetch(url).then((res) => (res.ok ? res.json() : null)).catch(() => null);
  }

  // Mesma fusão que o FGIEngine faz: perfil base + ajustes do professor.
  function deepMerge(base, overrides) {
    if (!overrides) return base;
    const result = Object.assign({}, base);
    Object.keys(overrides).forEach((key) => {
      const value = overrides[key];
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        result[key] = deepMerge(base[key] || {}, value);
      } else {
        result[key] = value;
      }
    });
    return result;
  }

  function esc(t) {
    return String(t == null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function frameSrc(gameId, configuracoes) {
    return '../games/' + gameId + '/index.html?config=' + encodeURIComponent(JSON.stringify(configuracoes));
  }

  async function render() {
    const app = document.getElementById('app');
    const { jogo, perfil } = getParams();

    if (!jogo || !perfil) {
      window.location.href = 'dashboard.html';
      return;
    }

    app.innerHTML = '<p class="loading-message">Carregando modo teste...</p>';

    const [profile, manifest] = await Promise.all([
      fetchJSON('../profiles/' + perfil + '.json'),
      fetchJSON('../games/' + jogo + '/manifest.json'),
    ]);

    if (!profile) {
      app.innerHTML =
        '<div class="play-shell"><div class="play-topbar"><a class="play-back" href="dashboard.html">Voltar ao Painel</a></div>' +
        '<div class="layout"><p>Perfil não encontrado: ' + esc(perfil) + '</p></div></div>';
      return;
    }

    const teacherConfig = StorageService.getProfileConfig(perfil) || {};
    const configuracoes = deepMerge(profile.configuracoes, teacherConfig.ajustes);

    const gameFromCatalog = (window.GAME_CATALOG || []).find((g) => g.id === jogo);
    const nomeJogo = (manifest && manifest.nomeJogo) || (gameFromCatalog && gameFromCatalog.nomeJogo) || jogo;

    app.innerHTML =
      '<div class="play-shell">' +
      '<div class="play-topbar">' +
      '<div class="play-topbar-info">' +
      '<span class="play-badge">Modo Teste</span>' +
      '<span class="play-game-name">' + esc(nomeJogo) + '</span>' +
      '<span class="play-profile-chip">Perfil: ' + esc(profile.nomePerfil) + '</span>' +
      '</div>' +
      '<div class="play-topbar-actions">' +
      '<a class="btn secondary" href="dashboard.html">Trocar jogo/perfil</a>' +
      '<a class="btn" href="dashboard.html">Voltar ao Painel</a>' +
      '</div>' +
      '</div>' +
      '<div class="play-note">Este é um teste do professor. O jogo está adaptado ao perfil <strong>' +
      esc(profile.nomePerfil) + '</strong>. Nenhum resultado de aluno é gravado.</div>' +
      '<main class="play-stage">' +
      '<iframe id="game-frame" class="play-frame" title="Jogo (modo teste)" src="' + frameSrc(jogo, configuracoes) + '"></iframe>' +
      '</main>' +
      '</div>';

    window.addEventListener('message', function onMessage(event) {
      const data = event.data;
      if (!data || data.type !== 'JOGO_CONCLUIDO') return;

      const total = data.totalPerguntas || data.acertos + data.erros;
      const pontuacao = total ? Math.round((data.acertos / total) * 100) : 0;
      showResultOverlay({
        nomeJogo,
        nomePerfil: profile.nomePerfil,
        acertos: data.acertos,
        erros: data.erros,
        total,
        pontuacao,
        nivel: data.nivel,
        gameId: jogo,
        configuracoes,
      });
    });
  }

  function showResultOverlay(r) {
    const overlay = document.createElement('div');
    overlay.className = 'play-overlay';
    overlay.innerHTML =
      '<div class="play-modal" role="dialog" aria-modal="true" aria-label="Resultado do teste">' +
      '<span class="play-badge">Modo Teste — resultado não gravado</span>' +
      '<h3>' + esc(r.nomeJogo) + '</h3>' +
      '<p>Perfil testado: <strong>' + esc(r.nomePerfil) + '</strong></p>' +
      '<div class="play-result-stats">' +
      '<div class="play-stat"><span class="play-stat-value">' + r.pontuacao + '%</span><span class="play-stat-label">Aproveitamento</span></div>' +
      '<div class="play-stat"><span class="play-stat-value">' + r.acertos + '</span><span class="play-stat-label">Acertos</span></div>' +
      '<div class="play-stat"><span class="play-stat-value">' + r.erros + '</span><span class="play-stat-label">Erros</span></div>' +
      '</div>' +
      '<div class="play-result-actions">' +
      '<button class="btn" type="button" id="play-again">Jogar de novo</button>' +
      '<a class="btn secondary" href="dashboard.html">Voltar ao Painel</a>' +
      '</div>' +
      '</div>';
    document.body.appendChild(overlay);

    overlay.querySelector('#play-again').addEventListener('click', () => {
      overlay.remove();
      const frame = document.getElementById('game-frame');
      // Recarrega o jogo do zero mantendo a mesma configuração de perfil.
      frame.src = frameSrc(r.gameId, r.configuracoes);
    });
  }

  document.addEventListener('DOMContentLoaded', render);
})();
