(function () {
  function getPerfilId() {
    return new URLSearchParams(window.location.search).get('perfil');
  }

  async function fetchProfile(id) {
    const res = await fetch('../profiles/' + id + '.json');
    if (!res.ok) throw new Error('Perfil não encontrado: ' + id);
    return res.json();
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  function renderResetSection() {
    return (
      '<div class="card" style="margin-top:24px;">' +
      '<h2>Dados de Demonstração</h2>' +
      '<p>Restaura perfis, alunos e resultados para o estado inicial do protótipo.</p>' +
      '<button class="btn danger" id="reset-btn">Restaurar Dados de Demonstração</button>' +
      '</div>'
    );
  }

  async function render() {
    const perfilId = getPerfilId();
    const app = document.getElementById('app');

    let perfilSection = '<p>Selecione um perfil em <a href="profiles.html">Perfis de Apoio</a> para ajustar seus parâmetros.</p>';

    if (perfilId) {
      const base = await fetchProfile(perfilId);
      const config = StorageService.getProfileConfig(perfilId) || {};
      const overrides = config.overrides || {};
      const visual = Object.assign({}, base.configuracoes.visual, overrides.visual);
      const audio = Object.assign({}, base.configuracoes.audio, overrides.audio);
      const cognitivo = Object.assign({}, base.configuracoes.cognitivo, overrides.cognitivo);

      perfilSection =
        '<p>Perfil selecionado: <span class="badge">' +
        base.nome +
        '</span></p>' +
        '<form id="params-form" class="card">' +
        '<div class="form-field"><label><input type="checkbox" id="estimulosReduzidos" ' +
        (visual.estimulosReduzidos ? 'checked' : '') +
        ' /> Reduzir estímulos visuais</label></div>' +
        '<div class="form-field"><label><input type="checkbox" id="sonsReduzidos" ' +
        (audio.sonsReduzidos ? 'checked' : '') +
        ' /> Reduzir sons</label></div>' +
        '<div class="form-field"><label><input type="checkbox" id="mudo" ' +
        (audio.mudo ? 'checked' : '') +
        ' /> Mudo (sem som, travado no jogo)</label></div>' +
        '<div class="form-field"><label for="feedback">Frequência de feedback</label>' +
        '<select id="feedback">' +
        ['padrao', 'frequente', 'constante']
          .map((v) => '<option value="' + v + '" ' + (cognitivo.feedback === v ? 'selected' : '') + '>' + v + '</option>')
          .join('') +
        '</select></div>' +
        '<div class="form-field"><label><input type="checkbox" id="tempoIlimitado" ' +
        (cognitivo.tempoLimiteSegundos === null ? 'checked' : '') +
        ' /> Tempo ilimitado</label></div>' +
        '<button type="submit" class="btn">Salvar Configuração</button>' +
        '</form>';
    }

    app.innerHTML = TeacherNav.render('settings') + '<main class="layout"><h1>Configurações do Perfil</h1>' + perfilSection + renderResetSection() + '</main>';

    const form = document.getElementById('params-form');
    if (form) {
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const overrides = {
          visual: { estimulosReduzidos: document.getElementById('estimulosReduzidos').checked },
          audio: {
            sonsReduzidos: document.getElementById('sonsReduzidos').checked,
            mudo: document.getElementById('mudo').checked,
          },
          cognitivo: {
            feedback: document.getElementById('feedback').value,
            tempoLimiteSegundos: document.getElementById('tempoIlimitado').checked ? null : 300,
          },
        };
        StorageService.saveProfileConfig(perfilId, { overrides });
        showToast('Parâmetros salvos.');
      });
    }

    document.getElementById('reset-btn').addEventListener('click', () => {
      if (confirm('Tem certeza? Isso vai apagar alunos, resultados e configurações salvas.')) {
        StorageService.resetDemoData();
        showToast('Dados de demonstração restaurados.');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', render);
})();
