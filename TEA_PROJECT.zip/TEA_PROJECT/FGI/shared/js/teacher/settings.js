(function () {
  // Tela "Configurações" (globais). Os parâmetros por perfil (visual/áudio/cognitivo)
  // e os jogos por perfil ficam agora em "Perfil de Apoio". Aqui só ficam ajustes
  // globais: integração com a plataforma externa e restauração dos dados de demo.

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  function esc(valor) {
    return String(valor == null ? '' : valor)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;');
  }

  function renderIntegracaoSection() {
    const integracao = StorageService.getSettings().integracao || {};
    return (
      '<div class="card" style="margin-top:24px;">' +
      '<h2>Integração com Plataforma Externa</h2>' +
      '<p>Envia automaticamente cada atividade concluída para a plataforma da Educandus ' +
      '(um envio por execução). Deixe em branco para manter os resultados apenas neste dispositivo.</p>' +
      '<form id="integracao-form">' +
      '<div class="form-field"><label for="endpoint">URL do endpoint (POST)</label>' +
      '<input type="url" id="endpoint" placeholder="https://.../api/fgi/resultados" value="' + esc(integracao.endpoint) + '" /></div>' +
      '<div class="form-field"><label for="token">Token de autenticação (Bearer) — opcional</label>' +
      '<input type="text" id="token" placeholder="deixe em branco se não usar" value="' + esc(integracao.token) + '" /></div>' +
      '<button type="submit" class="btn">Salvar Integração</button>' +
      '</form>' +
      '</div>'
    );
  }

  function renderResetSection() {
    return (
      '<div class="card" style="margin-top:24px;">' +
      '<h2>Dados de Demonstração</h2>' +
      '<p>Restaura perfis, alunos e resultados para o estado inicial do protótipo.</p>' +
      '<button class="btn danger" id="reset-btn">Restaurar Dados de Demonstração</button>' +
      '</div>'
    );
  }

  function render() {
    const app = document.getElementById('app');
    app.innerHTML =
      TeacherNav.render('settings') +
      '<main class="layout">' +
      '<div class="dash-hero"><h1>Configurações</h1>' +
      '<p>Ajustes globais do portal. As configurações de cada perfil de apoio ficam em ' +
      '<a href="profiles.html">Perfil de Apoio</a>.</p></div>' +
      renderIntegracaoSection() +
      renderResetSection() +
      '</main>';

    const integracaoForm = document.getElementById('integracao-form');
    integracaoForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const endpoint = document.getElementById('endpoint').value.trim();
      const token = document.getElementById('token').value.trim();
      const atual = StorageService.getSettings();
      StorageService.saveSettings(Object.assign({}, atual, { integracao: { endpoint, token } }));
      showToast('Integração salva.');
    });

    document.getElementById('reset-btn').addEventListener('click', () => {
      if (confirm('Tem certeza? Isso vai apagar alunos, resultados e configurações salvas.')) {
        StorageService.resetDemoData();
        showToast('Dados de demonstração restaurados.');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', render);
})();
