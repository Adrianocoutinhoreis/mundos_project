(function () {
  // Tela "Jogos Disponíveis" (item Jogos do menu). Lista os jogos do catálogo em
  // cards com tags de perfil de apoio (habilitar/desabilitar via "+ TAG"), filtros
  // por perfil e o botão Jogar (modo teste). Ver game-ui.js para o card e as tags.

  function fetchJSON(url) {
    return fetch(url).then((res) => (res.ok ? res.json() : null)).catch(() => null);
  }

  function getPerfilParam() {
    return new URLSearchParams(window.location.search).get('perfil');
  }

  async function render() {
    const app = document.getElementById('app');
    app.innerHTML =
      TeacherNav.render('games', { search: true, searchId: 'games-search' }) +
      '<main class="layout"><p>Carregando jogos...</p></main>';

    // Nomes legíveis dos perfis (para o modal de jogar e menus de tag).
    const ids = window.PROFILE_CATALOG_IDS;
    const profiles = await Promise.all(ids.map((id) => fetchJSON('../profiles/' + id + '.json')));
    const nameById = {};
    ids.forEach((id, i) => {
      nameById[id] = (profiles[i] && profiles[i].nomePerfil) || id;
    });
    TeacherGameUI.setProfileNames(nameById);

    const manifests = await Promise.all(
      window.GAME_CATALOG.map((g) => fetchJSON('../games/' + g.id + '/manifest.json'))
    );
    const cardsHtml = window.GAME_CATALOG.map((g, i) => TeacherGameUI.renderGameCard(g, manifests[i])).join('');

    const pillsHtml = ids
      .map((pid) => {
        const s = TeacherGameUI.styleFor(pid);
        return (
          '<button class="filter-pill" type="button" data-perfil="' + pid + '">' +
          '<span class="filter-dot" style="background:' + s.color + '"></span>' + s.label +
          '</button>'
        );
      })
      .join('');

    const main =
      '<main class="layout">' +
      '<div class="games-toolbar">' +
      '<div class="games-toolbar-head">' +
      '<h1>Jogos Disponíveis</h1>' +
      '<p class="section-sub">Selecione atividades pedagógicas gamificadas para seus alunos.</p>' +
      '</div>' +
      '<button class="btn-filtros" id="btn-filtros" type="button" aria-expanded="true">' +
      '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="10" y1="18" x2="14" y2="18"/></svg>' +
      ' Filtros</button>' +
      '</div>' +
      '<div class="game-filters" id="game-filters">' +
      pillsHtml +
      '<button class="filter-clear" id="filter-clear" type="button">Limpar filtros</button>' +
      '</div>' +
      '<div class="games-grid" id="games-grid">' + cardsHtml + '</div>' +
      '</main>';

    app.innerHTML = TeacherNav.render('games', { search: true, searchId: 'games-search' }) + main;

    const grid = document.getElementById('games-grid');
    const searchInput = document.getElementById('games-search');
    const activeFilters = {};

    function anyFilter() {
      return Object.keys(activeFilters).length > 0;
    }

    function applyFilters() {
      const q = (searchInput && searchInput.value ? searchInput.value : '').trim().toLowerCase();
      const filterIds = Object.keys(activeFilters);
      grid.querySelectorAll('.game-card').forEach((card) => {
        const gameId = card.dataset.game;
        const enabled = {};
        TeacherGameUI.enabledProfilesForGame(gameId).forEach((pid) => {
          enabled[pid] = true;
        });
        const matchFilter = !anyFilter() || filterIds.some((pid) => enabled[pid]);
        const matchSearch = !q || (card.dataset.search || '').indexOf(q) !== -1;
        card.style.display = matchFilter && matchSearch ? '' : 'none';
      });
    }

    TeacherGameUI.bindContainer(grid, { onChange: applyFilters });

    document.querySelectorAll('.filter-pill').forEach((pill) => {
      pill.addEventListener('click', () => {
        const p = pill.dataset.perfil;
        if (activeFilters[p]) {
          delete activeFilters[p];
          pill.classList.remove('active');
        } else {
          activeFilters[p] = true;
          pill.classList.add('active');
        }
        applyFilters();
      });
    });

    document.getElementById('filter-clear').addEventListener('click', () => {
      Object.keys(activeFilters).forEach((k) => delete activeFilters[k]);
      document.querySelectorAll('.filter-pill.active').forEach((p) => p.classList.remove('active'));
      applyFilters();
    });

    const btnFiltros = document.getElementById('btn-filtros');
    btnFiltros.addEventListener('click', () => {
      const bar = document.getElementById('game-filters');
      const collapsed = bar.classList.toggle('collapsed');
      btnFiltros.setAttribute('aria-expanded', String(!collapsed));
    });

    if (searchInput) searchInput.addEventListener('input', applyFilters);

    // Se veio de um perfil (ex.: link antigo games.html?perfil=X), já filtra por ele.
    const preset = getPerfilParam();
    if (preset && nameById[preset]) {
      const pill = document.querySelector('.filter-pill[data-perfil="' + preset + '"]');
      if (pill) {
        activeFilters[preset] = true;
        pill.classList.add('active');
        applyFilters();
      }
    }
  }

  document.addEventListener('DOMContentLoaded', render);
})();
