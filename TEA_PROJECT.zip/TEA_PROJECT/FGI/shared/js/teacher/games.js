(function () {
  function getPerfilId() {
    return new URLSearchParams(window.location.search).get('perfil');
  }

  async function fetchProfile(id) {
    const res = await fetch('../profiles/' + id + '.json');
    if (!res.ok) throw new Error('Perfil não encontrado: ' + id);
    return res.json();
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  }

  async function render() {
    const perfilId = getPerfilId();
    const app = document.getElementById('app');

    if (!perfilId) {
      app.innerHTML =
        TeacherNav.render('games') +
        '<main class="layout">' +
        '<h1>Jogos Disponíveis</h1>' +
        '<p>Selecione um perfil na tela <a href="profiles.html">Perfis de Apoio</a> antes de configurar os jogos.</p>' +
        '</main>';
      return;
    }

    const profile = await fetchProfile(perfilId);
    const config = StorageService.getProfileConfig(perfilId) || { jogosHabilitados: [] };
    const enabled = new Set(config.jogosHabilitados);

    const checklist = window.GAME_CATALOG.map(
      (game) =>
        '<label class="checklist-item"><input type="checkbox" data-game-id="' +
        game.id +
        '" ' +
        (enabled.has(game.id) ? 'checked' : '') +
        ' /> ' +
        game.nome +
        '</label>'
    ).join('');

    app.innerHTML =
      TeacherNav.render('games') +
      '<main class="layout">' +
      '<h1>Jogos Disponíveis</h1>' +
      '<p>Perfil selecionado: <span class="badge">' +
      profile.nome +
      '</span></p>' +
      '<div class="card">' +
      '<p>Marque quais jogos ficam disponíveis para alunos com este perfil. A adaptação visual, sonora e cognitiva de cada jogo é aplicada automaticamente pelo FGI Engine a partir do perfil — não é necessário configurar jogo por jogo.</p>' +
      '<div id="checklist">' +
      checklist +
      '</div>' +
      '</div>' +
      '<div style="margin-top:16px; display:flex; gap:12px; flex-wrap: wrap;">' +
      '<button class="btn" id="save-btn">Salvar Configuração</button>' +
      '<a class="btn secondary" href="settings.html?perfil=' +
      perfilId +
      '">Ajustar Parâmetros do Perfil</a>' +
      '</div>' +
      '</main>';

    document.getElementById('save-btn').addEventListener('click', () => {
      const checkboxes = document.querySelectorAll('#checklist input[type="checkbox"]');
      const jogosHabilitados = Array.from(checkboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.dataset.gameId);
      StorageService.saveProfileConfig(perfilId, { jogosHabilitados });
      showToast('Configuração salva para ' + profile.nome);
    });
  }

  document.addEventListener('DOMContentLoaded', render);
})();
