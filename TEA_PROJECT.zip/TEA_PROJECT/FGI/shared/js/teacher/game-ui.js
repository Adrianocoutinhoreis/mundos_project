(function (global) {
  // Componente de card de jogo compartilhado entre o Painel (dashboard) e a tela
  // "Jogos Disponíveis" (games). Responsável por:
  //  - renderizar o card (thumbnail, título, descrição, botão Jogar, tags + "+ TAG")
  //  - gerenciar as tags de perfil (adicionar/remover = habilitar/desabilitar o jogo
  //    naquele perfil, gravando em jogosHabilitados — fonte única de verdade)
  //  - abrir o modo teste (Jogar) usando o perfil da tag (modal quando há mais de um)

  // Estilo/rótulo curto por perfil de apoio (cores acessíveis, uma por perfil).
  const PROFILE_STYLE = {
    tipico: { label: 'Típico', color: '#15803d', bg: '#e7f6ec', border: '#c3e9cf' },
    tea_1: { label: 'TEA 1', color: '#1d4ed8', bg: '#e8f0ff', border: '#cfe0ff' },
    tea_2: { label: 'TEA 2', color: '#c2410c', bg: '#fff0e2', border: '#ffd9b8' },
    tea_3: { label: 'TEA 3', color: '#0e7490', bg: '#e0f5fa', border: '#bde8f1' },
    tdah: { label: 'TDAH', color: '#6d28d9', bg: '#f1e9ff', border: '#ddc9fb' },
    dislexia: { label: 'Dislexia', color: '#be185d', bg: '#fce7f1', border: '#f6c9dd' },
  };

  let PROFILE_NAMES = {};

  function setProfileNames(map) {
    PROFILE_NAMES = map || {};
  }

  function styleFor(id) {
    return PROFILE_STYLE[id] || { label: id, color: '#334155', bg: '#eef2f7', border: '#dbe3ec' };
  }

  function nameFor(id) {
    return PROFILE_NAMES[id] || styleFor(id).label;
  }

  function esc(text) {
    return String(text == null ? '' : text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function allProfileIds() {
    return window.PROFILE_CATALOG_IDS || [];
  }

  // Perfis em que o jogo está habilitado (lê o estado atual do storage).
  function enabledProfilesForGame(gameId) {
    const cfg = StorageService.getProfilesConfig();
    return allProfileIds().filter((pid) => {
      const c = cfg[pid];
      return c && Array.isArray(c.jogosHabilitados) && c.jogosHabilitados.indexOf(gameId) !== -1;
    });
  }

  // Habilita/desabilita um jogo em um perfil (grava em jogosHabilitados).
  function setGameProfile(gameId, perfilId, enable) {
    const cfg = StorageService.getProfileConfig(perfilId) || { jogosHabilitados: [] };
    const set = {};
    (cfg.jogosHabilitados || []).forEach((id) => {
      set[id] = true;
    });
    if (enable) set[gameId] = true;
    else delete set[gameId];
    StorageService.saveProfileConfig(perfilId, { jogosHabilitados: Object.keys(set) });
  }

  function tagPill(perfilId, removable) {
    const s = styleFor(perfilId);
    const removeBtn = removable
      ? '<button class="game-tag-remove" type="button" data-perfil="' + perfilId + '" ' +
        'title="Remover perfil" aria-label="Remover ' + esc(s.label) + '">&times;</button>'
      : '';
    return (
      '<span class="game-tag" data-perfil="' + perfilId + '" ' +
      'style="color:' + s.color + ';background:' + s.bg + ';border-color:' + s.border + ';">' +
      esc(s.label) + removeBtn +
      '</span>'
    );
  }

  // removable=false: mostra as tags e o "+ TAG" (adição rápida), mas sem o × de remover.
  function tagsInnerHtml(gameId, removable) {
    const canRemove = removable !== false;
    const pills = enabledProfilesForGame(gameId).map((pid) => tagPill(pid, canRemove)).join('');
    return pills + '<button class="tag-add" type="button" title="Disponibilizar para um perfil (usa as configurações padrão do perfil)">+ TAG</button>';
  }

  function searchTextFor(nome, descricao, gameId) {
    const labels = enabledProfilesForGame(gameId)
      .map((pid) => styleFor(pid).label + ' ' + nameFor(pid))
      .join(' ');
    return (nome + ' ' + descricao + ' ' + labels).toLowerCase();
  }

  // opts.showTags (padrão true): oculta o bloco de tags.
  // opts.tagsRemovable (padrão true): quando false, mostra tags + "+ TAG" mas sem o × de remover.
  function renderGameCard(game, manifest, opts) {
    const showTags = !opts || opts.showTags !== false;
    const removable = !opts || opts.tagsRemovable !== false;
    const nome = (manifest && manifest.nomeJogo) || game.nomeJogo;
    const descricao = (manifest && manifest.descricao) || 'Atividade pedagógica adaptável ao perfil do aluno.';
    const mascote = (manifest && manifest.mascote) || '🎮';
    const cor = (manifest && manifest.corTema) || '#2563eb';

    return (
      '<article class="game-card" data-game="' + esc(game.id) + '" data-search="' +
      esc(searchTextFor(nome, descricao, game.id)) + '">' +
      '<div class="game-thumb" style="background: radial-gradient(circle at 30% 25%, rgba(255,255,255,0.28), transparent 60%), ' +
      cor + ';"><span aria-hidden="true">' + mascote + '</span></div>' +
      '<div class="game-body">' +
      '<h3>' + esc(nome) + '</h3>' +
      '<p class="game-desc">' + esc(descricao) + '</p>' +
      '<button class="btn-play" type="button" data-game="' + esc(game.id) + '" data-game-name="' + esc(nome) + '">' +
      '<svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4"/></svg> Jogar' +
      '</button>' +
      (showTags ? '<div class="game-tags" data-game="' + esc(game.id) + '" data-removable="' + removable + '">' + tagsInnerHtml(game.id, removable) + '</div>' : '') +
      '</div>' +
      '</article>'
    );
  }

  // ---------- Interações ----------
  let closeActiveMenu = null;

  function refreshTags(tagsEl) {
    const gameId = tagsEl.dataset.game;
    const removable = tagsEl.dataset.removable !== 'false';
    tagsEl.innerHTML = tagsInnerHtml(gameId, removable);
    const card = tagsEl.closest('.game-card');
    if (card) {
      const h3 = card.querySelector('h3');
      const desc = card.querySelector('.game-desc');
      card.dataset.search = searchTextFor(
        h3 ? h3.textContent : '',
        desc ? desc.textContent : '',
        gameId
      );
    }
  }

  function openAddMenu(tagsEl, onChange) {
    if (closeActiveMenu) closeActiveMenu();
    const gameId = tagsEl.dataset.game;
    const enabled = {};
    enabledProfilesForGame(gameId).forEach((pid) => {
      enabled[pid] = true;
    });
    const addable = allProfileIds().filter((pid) => !enabled[pid]);

    const menu = document.createElement('div');
    menu.className = 'tag-menu';
    if (!addable.length) {
      menu.innerHTML = '<div class="tag-menu-empty">Todos os perfis já foram adicionados.</div>';
    } else {
      menu.innerHTML = addable
        .map((pid) => {
          const s = styleFor(pid);
          return (
            '<button class="tag-menu-item" type="button" data-perfil="' + pid + '">' +
            '<span class="tag-dot" style="background:' + s.color + '"></span>' + esc(nameFor(pid)) +
            '</button>'
          );
        })
        .join('');
    }
    tagsEl.appendChild(menu);

    menu.addEventListener('click', (e) => {
      const item = e.target.closest('.tag-menu-item');
      if (!item) return;
      setGameProfile(gameId, item.dataset.perfil, true);
      close();
      refreshTags(tagsEl);
      if (onChange) onChange();
    });

    function onDocClick(e) {
      if (!menu.contains(e.target) && !e.target.closest('.tag-add')) close();
    }
    function onKey(e) {
      if (e.key === 'Escape') close();
    }
    function close() {
      menu.remove();
      document.removeEventListener('click', onDocClick, true);
      document.removeEventListener('keydown', onKey);
      closeActiveMenu = null;
    }
    closeActiveMenu = close;
    // Adia o registro para não capturar o próprio clique que abriu o menu.
    setTimeout(() => document.addEventListener('click', onDocClick, true), 0);
    document.addEventListener('keydown', onKey);
  }

  function bindTags(tagsEl, onChange) {
    tagsEl.addEventListener('click', (e) => {
      const removeBtn = e.target.closest('.game-tag-remove');
      if (removeBtn) {
        setGameProfile(tagsEl.dataset.game, removeBtn.dataset.perfil, false);
        refreshTags(tagsEl);
        if (onChange) onChange();
        return;
      }
      if (e.target.closest('.tag-add')) {
        openAddMenu(tagsEl, onChange);
      }
    });
  }

  function bindContainer(container, opts) {
    const options = opts || {};
    const onChange = options.onChange || function () {};

    container.querySelectorAll('.btn-play').forEach((btn) => {
      btn.addEventListener('click', () => {
        const gameId = btn.dataset.game;
        const gameName = btn.dataset.gameName;
        const enabled = enabledProfilesForGame(gameId);
        const choices = enabled.length ? enabled : allProfileIds().slice();
        if (choices.length === 1) {
          goToPlay(gameId, choices[0]);
          return;
        }
        openProfilePickerModal(gameId, gameName, choices, enabled.length === 0);
      });
    });

    container.querySelectorAll('.game-tags').forEach((tagsEl) => bindTags(tagsEl, onChange));
  }

  function goToPlay(gameId, perfilId) {
    window.location.href = 'play.html?jogo=' + encodeURIComponent(gameId) + '&perfil=' + encodeURIComponent(perfilId);
  }

  function openProfilePickerModal(gameId, gameName, choices, isFallback) {
    const overlay = document.createElement('div');
    overlay.className = 'play-overlay';

    const list = choices
      .map(
        (pid) =>
          '<button class="play-profile-btn" type="button" data-perfil="' + pid + '">' +
          '<span>' + esc(nameFor(pid)) + '</span>' +
          '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>' +
          '</button>'
      )
      .join('');

    overlay.innerHTML =
      '<div class="play-modal" role="dialog" aria-modal="true" aria-label="Escolher perfil para jogar">' +
      '<h3>Jogar: ' + esc(gameName) + '</h3>' +
      '<p>' +
      (isFallback
        ? 'Este jogo ainda não está habilitado em nenhum perfil. Escolha um perfil para testar (modo teste, sem gravar resultado).'
        : 'Escolha com qual perfil de apoio deseja testar este jogo. É um teste do professor — nenhum resultado de aluno é gravado.') +
      '</p>' +
      '<div class="play-profile-list">' + list + '</div>' +
      '<button class="play-modal-close" type="button">Cancelar</button>' +
      '</div>';

    document.body.appendChild(overlay);

    function close() {
      overlay.remove();
      document.removeEventListener('keydown', onKey);
    }
    function onKey(e) {
      if (e.key === 'Escape') close();
    }
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close();
    });
    overlay.querySelector('.play-modal-close').addEventListener('click', close);
    overlay.querySelectorAll('.play-profile-btn').forEach((b) => {
      b.addEventListener('click', () => goToPlay(gameId, b.dataset.perfil));
    });
    document.addEventListener('keydown', onKey);
  }

  global.TeacherGameUI = {
    PROFILE_STYLE,
    styleFor,
    nameFor,
    setProfileNames,
    enabledProfilesForGame,
    renderGameCard,
    bindContainer,
    goToPlay,
  };
})(window);
