(function (global) {
  const STUDENT_KEY = 'fgi:sessao:alunoId';
  const LAST_RESULT_KEY = 'fgi:sessao:ultimoResultadoId';

  const StudentSession = {
    getCurrentStudentId() {
      return sessionStorage.getItem(STUDENT_KEY);
    },
    setCurrentStudentId(id) {
      sessionStorage.setItem(STUDENT_KEY, id);
    },
    clear() {
      sessionStorage.removeItem(STUDENT_KEY);
      sessionStorage.removeItem(LAST_RESULT_KEY);
    },
    setLastResultId(id) {
      sessionStorage.setItem(LAST_RESULT_KEY, id);
    },
    getLastResultId() {
      return sessionStorage.getItem(LAST_RESULT_KEY);
    },
    // Redireciona para o login se não houver aluno autenticado; devolve o id caso exista.
    requireLogin(redirectTo) {
      const id = this.getCurrentStudentId();
      if (!id) {
        window.location.href = redirectTo || 'login.html';
        return null;
      }
      return id;
    },
  };

  global.StudentSession = StudentSession;
})(window);
