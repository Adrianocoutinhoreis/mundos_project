// Lista de perfis de apoio disponíveis (profiles/*.json). Mantida separada pois
// fetch() não lista diretórios — precisa saber de antemão quais arquivos existem.
window.PROFILE_CATALOG_IDS = ['tipico', 'tea_1', 'tea_2', 'tea_3', 'tdah', 'dislexia'];
