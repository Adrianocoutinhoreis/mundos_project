(function (global) {
  const ICON_HELP =
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';

  function render(student) {
    if (!student) return '';
    return (
      '<header class="student-header"><div class="layout">' +
      '<a class="brand" href="home.html">FGI</a>' +
      '<div class="student-header-info">' +
      '<span class="student-name">Olá, ' + student.nome + '</span>' +
      '<button class="help-btn" type="button" title="Ajuda" aria-label="Ajuda">' + ICON_HELP + '</button>' +
      '<button class="btn secondary" id="logout-btn" type="button">Sair</button>' +
      '</div>' +
      '</div></header>'
    );
  }

  function bindLogout() {
    const btn = document.getElementById('logout-btn');
    if (btn) {
      btn.addEventListener('click', () => {
        StudentSession.clear();
        window.location.href = 'login.html';
      });
    }
  }

  global.StudentNav = { render, bindLogout };
})(window);
