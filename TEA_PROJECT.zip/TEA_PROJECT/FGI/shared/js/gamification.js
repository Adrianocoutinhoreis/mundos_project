// Fonte ÚNICA da verdade das faixas de desempenho do FGI.
//
// Cada atividade concluída gera uma `pontuacao` (0-100) = % de acerto na primeira
// tentativa (ver student/game.js). Essa pontuação cai numa das três faixas abaixo,
// e da faixa saem: estrelas (1-3), pontos (mínimo/médio/máximo) e o nível de
// proficiência mostrado ao professor. Mudou aqui, mudou no sistema inteiro —
// nenhum outro arquivo deve repetir os limites 80/50.
(function (global) {
  // Ordem decrescente por minAcerto: a primeira faixa cujo limite a pontuação
  // alcança é a faixa da criança.
  const FAIXAS = [
    {
      nivel: 'maximo',
      minAcerto: 80, // >= 80% de acerto (7-8 de 8)
      estrelas: 3,
      pontos: 500,
      rotulo: 'Excelente!',
      proficiencia: { texto: 'Acima', className: 'badge-success', titulo: 'Proficiente' },
    },
    {
      nivel: 'medio',
      minAcerto: 50, // 50-79% de acerto (4-6 de 8)
      estrelas: 2,
      pontos: 300,
      rotulo: 'Muito bem!',
      proficiencia: { texto: 'No Nível', className: 'badge-warning', titulo: 'Inicial' },
    },
    {
      nivel: 'minimo',
      minAcerto: 0, // qualquer conclusão vale a faixa mínima (erro nunca zera)
      estrelas: 1,
      pontos: 100,
      rotulo: 'Bom começo!',
      proficiencia: { texto: 'Abaixo', className: 'badge-danger', titulo: 'Familiar' },
    },
  ];

  // A faixa correspondente a uma pontuação (0-100). Nunca retorna null: se algo vier
  // fora do previsto, cai na faixa mínima (a última da lista).
  function faixaPorPontuacao(pontuacao) {
    const p = Number(pontuacao) || 0;
    return FAIXAS.find((faixa) => p >= faixa.minAcerto) || FAIXAS[FAIXAS.length - 1];
  }

  function estrelasPorPontuacao(pontuacao) {
    return faixaPorPontuacao(pontuacao).estrelas;
  }

  function pontosPorPontuacao(pontuacao) {
    return faixaPorPontuacao(pontuacao).pontos;
  }

  function totalEstrelas(resultados) {
    return resultados.reduce((soma, r) => soma + estrelasPorPontuacao(r.pontuacao || 0), 0);
  }

  function totalPontos(resultados) {
    return resultados.reduce((soma, r) => soma + pontosPorPontuacao(r.pontuacao || 0), 0);
  }

  // Nível de proficiência a partir da MÉDIA das pontuações do aluno (usado no
  // relatório do professor). Reaproveita as mesmas faixas.
  function proficienciaPorMedia(media) {
    return faixaPorPontuacao(media).proficiencia;
  }

  global.Gamification = {
    FAIXAS,
    faixaPorPontuacao,
    estrelasPorPontuacao,
    pontosPorPontuacao,
    totalEstrelas,
    totalPontos,
    proficienciaPorMedia,
  };
})(window);
