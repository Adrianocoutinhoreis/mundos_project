(function (global) {
  const DEFAULT_PROFILES_PATH = '../profiles/';

  // Estados do Perfil Adaptativo (02_SYSTEM_STATES.md)
  const STATES = {
    LOADED: 'loaded',
    APPLYING_CONFIGURATION: 'applying_configuration',
    VISUAL_APPLIED: 'visual_configuration_applied',
    AUDIO_APPLIED: 'audio_configuration_applied',
    GAMEPLAY_APPLIED: 'gameplay_configuration_applied',
    READY: 'ready',
  };

  // Estados do Jogo (02_SYSTEM_STATES.md)
  const GAME_STATES = {
    IDLE: 'idle',
    LOADING: 'loading',
    TUTORIAL: 'tutorial',
    PLAYING: 'playing',
    PAUSED: 'paused',
    FINISHED: 'finished',
  };

  function deepMerge(base, overrides) {
    if (!overrides) return base;
    const result = Object.assign({}, base);
    Object.keys(overrides).forEach((key) => {
      const value = overrides[key];
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        result[key] = deepMerge(base[key] || {}, value);
      } else {
        result[key] = value;
      }
    });
    return result;
  }

  async function fetchBaseProfile(perfilId, profilesBasePath) {
    const response = await fetch(profilesBasePath + perfilId + '.json');
    if (!response.ok) {
      throw new Error('Perfil não encontrado: ' + perfilId);
    }
    return response.json();
  }

  // Nota: adaptações visuais/sonoras (contraste, tamanho de fonte, animações, etc.) só se
  // aplicam DENTRO do jogo (via ?config= no iframe, ver games/soma/script.js). O shell do FGI
  // (login, home, activities, result) mantém sempre o mesmo layout para todos os perfis.
  function applyAudioConfig(audio) {
    global.FGIEngine.audioConfig = audio;
  }

  function applyCognitiveConfig(cognitivo) {
    global.FGIEngine.cognitiveConfig = cognitivo;
  }

  // Carrega o aluno -> perfil base (profiles/*.json) -> ajustes do professor -> aplica em ordem
  // visual -> áudio -> cognitivo, notificando cada transição de estado via onStateChange.
  async function loadStudentProfile(studentId, options) {
    const opts = options || {};
    const profilesBasePath = opts.profilesBasePath || DEFAULT_PROFILES_PATH;
    const onStateChange = opts.onStateChange || function () {};

    const student = StorageService.getStudentById(studentId);
    if (!student) {
      throw new Error('Aluno não encontrado: ' + studentId);
    }

    onStateChange(STATES.LOADED, { student });

    const baseProfile = await fetchBaseProfile(student.nivelDeApoio, profilesBasePath);
    const teacherConfig = StorageService.getProfileConfig(student.nivelDeApoio) || {};
    const configuracoes = deepMerge(baseProfile.configuracoes, teacherConfig.ajustes);

    onStateChange(STATES.APPLYING_CONFIGURATION, { student, baseProfile, configuracoes });
    onStateChange(STATES.VISUAL_APPLIED, { configuracoes });

    applyAudioConfig(configuracoes.audio);
    onStateChange(STATES.AUDIO_APPLIED, { configuracoes });

    applyCognitiveConfig(configuracoes.cognitivo);
    onStateChange(STATES.GAMEPLAY_APPLIED, { configuracoes });

    const perfilAtivo = {
      student,
      nivelDeApoio: student.nivelDeApoio,
      nomePerfil: baseProfile.nomePerfil,
      configuracoes,
      jogosHabilitados: teacherConfig.jogosHabilitados || [],
    };

    onStateChange(STATES.READY, perfilAtivo);

    return perfilAtivo;
  }

  // Sessão de jogo isolada: o jogo só recebe perfilAtivo.configuracoes e devolve um resultado.
  function createGameSession(gameId, perfilAtivo) {
    let state = GAME_STATES.IDLE;
    const startedAt = Date.now();
    const listeners = [];

    function setState(next) {
      state = next;
      listeners.forEach((listener) => listener(state));
    }

    return {
      get state() {
        return state;
      },
      onStateChange(listener) {
        listeners.push(listener);
      },
      load() {
        setState(GAME_STATES.LOADING);
      },
      startTutorial() {
        setState(GAME_STATES.TUTORIAL);
      },
      play() {
        setState(GAME_STATES.PLAYING);
      },
      pause() {
        setState(GAME_STATES.PAUSED);
      },
      resume() {
        setState(GAME_STATES.PLAYING);
      },
      finish(resultData) {
        setState(GAME_STATES.FINISHED);
        const tempoSegundos = Math.round((Date.now() - startedAt) / 1000);
        const result = Object.assign(
          {
            alunoId: perfilAtivo.student.id,
            nomeAluno: perfilAtivo.student.nomeAluno,
            jogoId: gameId,
            nivelDeApoio: perfilAtivo.nivelDeApoio,
            tempoSegundos,
            concluidoEm: new Date().toISOString(),
          },
          resultData
        );
        return StorageService.addGameResult(result);
      },
    };
  }

  global.FGIEngine = {
    STATES,
    GAME_STATES,
    loadStudentProfile,
    createGameSession,
    audioConfig: null,
    cognitiveConfig: null,
  };
})(window);
