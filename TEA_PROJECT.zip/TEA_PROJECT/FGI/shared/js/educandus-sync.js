(function (global) {
  // Envio dos resultados para a plataforma externa (Educandus).
  //
  // Princípio: UM objeto por execução. O único ponto que dispara o envio é
  // StorageService.addGameResult() — cada jogada passa por lá exatamente uma vez.
  // Nada aqui reenvia o array acumulado; o reenvio é individual e idempotente
  // (o servidor deve fazer upsert por resultado.id).
  //
  // Resiliência: se não houver endpoint configurado ou a rede falhar, o resultado
  // fica com `enviado: false` no localStorage e é reenviado depois por
  // sincronizarPendentes() (chamado, por exemplo, ao abrir os relatórios).
  const VERSAO_APP = 'FGI-1.0';

  function getIntegracao() {
    const settings = global.StorageService ? StorageService.getSettings() : {};
    return (settings && settings.integracao) || {};
  }

  function montarPayload(entry) {
    // Envelope estável. `enviado` é controle INTERNO de sincronização e não vai
    // para a API — só seguem os dados da atividade. O `id` serve como chave de
    // idempotência para o servidor.
    const { enviado, ...resultado } = entry;
    return { evento: 'atividade_concluida', versaoApp: VERSAO_APP, resultado };
  }

  async function postar(entry) {
    const cfg = getIntegracao();
    if (!cfg.endpoint) return false; // integração não configurada → mantém só local
    try {
      const headers = { 'Content-Type': 'application/json' };
      if (cfg.token) headers.Authorization = 'Bearer ' + cfg.token;
      const resp = await fetch(cfg.endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(montarPayload(entry)),
      });
      return resp.ok;
    } catch (err) {
      return false; // rede indisponível → resultado fica pendente para reenvio
    }
  }

  // Chamado a cada execução (fire-and-forget). Nunca lança: se falhar, o
  // resultado permanece pendente e será reenviado por sincronizarPendentes().
  async function enviar(entry) {
    if (await postar(entry)) StorageService.markResultSent(entry.id);
  }

  // Varredor: reenvia SÓ os resultados pendentes (enviado !== true), nunca o
  // histórico inteiro. Retorna um resumo para a UI.
  async function sincronizarPendentes() {
    const pendentes = StorageService.getPendingResults();
    let enviados = 0;
    for (const r of pendentes) {
      if (await postar(r)) {
        StorageService.markResultSent(r.id);
        enviados += 1;
      }
    }
    return { total: pendentes.length, enviados };
  }

  function estaConfigurado() {
    return Boolean(getIntegracao().endpoint);
  }

  global.EducandusSync = { enviar, sincronizarPendentes, estaConfigurado };
})(window);
