(function () {
  function getGameId() {
    return new URLSearchParams(window.location.search).get('jogo');
  }

  // Contrato do jogo: <iframe src="../games/<id>/index.html?config=<configuracoes em JSON>">.
  // O jogo é isolado num documento próprio, não conhece aluno/professor, e ao concluir
  // envia window.parent.postMessage({ type: 'JOGO_CONCLUIDO', acertos, erros, totalPerguntas, nivel }).
  function renderGameFrame(perfilAtivo, gameId) {
    const configParam = encodeURIComponent(JSON.stringify(perfilAtivo.configuracoes));
    document.getElementById('app').innerHTML =
      StudentNav.render(perfilAtivo.student) +
      '<main class="layout">' +
      '<iframe id="game-frame" class="game-frame" title="Jogo" src="../games/' +
      gameId +
      '/index.html?config=' +
      configParam +
      '"></iframe>' +
      '</main>';

    // Nesta tela "Sair" significa deixar a atividade, não encerrar a sessão do aluno.
    document.getElementById('logout-btn').addEventListener('click', () => {
      window.location.href = 'home.html';
    });
  }

  async function render() {
    const studentId = StudentSession.requireLogin();
    if (!studentId) return;

    const gameId = getGameId();
    if (!gameId) {
      window.location.href = 'activities.html';
      return;
    }

    document.getElementById('app').innerHTML = '<p class="loading-message">Carregando...</p>';

    const perfilAtivo = await FGIEngine.loadStudentProfile(studentId);
    const session = FGIEngine.createGameSession(gameId, perfilAtivo);
    session.load();
    session.startTutorial();

    renderGameFrame(perfilAtivo, gameId);
    session.play();

    window.addEventListener('message', function onMessage(event) {
      const data = event.data;
      if (!data || data.type !== 'JOGO_CONCLUIDO') return;
      window.removeEventListener('message', onMessage);

      const total = data.totalPerguntas || data.acertos + data.erros;
      const pontuacao = total ? Math.round((data.acertos / total) * 100) : 0;

      const entry = session.finish({
        pontuacao,
        // Escore auto-descritivo para a plataforma externa: a % de acerto sempre
        // vai de 0 a 100 (o `pontuacao` já é esse valor). Assim o destino sabe a
        // escala sem precisar assumir nada.
        escore: { atual: pontuacao, minima: 0, maxima: 100 },
        tentativas: data.acertos + data.erros,
        sucesso: data.erros === 0,
        detalhes: 'Acertos: ' + data.acertos + ' de ' + total + (data.nivel ? ' (nível ' + data.nivel + ')' : ''),
      });

      StudentSession.setLastResultId(entry.id);
      window.location.href = 'result.html';
    });
  }

  document.addEventListener('DOMContentLoaded', render);
})();
