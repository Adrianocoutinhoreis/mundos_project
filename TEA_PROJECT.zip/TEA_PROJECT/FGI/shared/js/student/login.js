(function () {
  const ICON_USER =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>';
  const ICON_LOCK =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>';
  const ICON_EYE =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
  const ICON_EYE_OFF =
    '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a18.66 18.66 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a18.66 18.66 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>';

  function render() {
    if (StudentSession.getCurrentStudentId()) {
      window.location.href = 'home.html';
      return;
    }

    document.getElementById('app').innerHTML =
      '<main class="login-screen">' +
      '<div class="login-panel-left">' +
      '<h1 class="login-greeting">Oi,<br>Amigo!</h1>' +
      '<p class="login-greeting-subtitle">Estamos muito felizes em ver você hoje. Vamos começar nossa aventura?</p>' +
      '</div>' +
      '<div class="login-panel-right">' +
      '<div class="login-form-wrap">' +
      '<div class="login-tabs"><span class="login-tab active">Entrar</span></div>' +
      '<form id="login-form">' +
      '<div class="form-field icon-field">' +
      '<label for="login">Nome</label>' +
      '<div class="input-with-icon">' +
      '<span class="input-icon">' + ICON_USER + '</span>' +
      '<input id="login" name="login" type="text" autocomplete="username" placeholder="Qual o seu nome?" required />' +
      '</div>' +
      '</div>' +
      '<div class="form-field icon-field">' +
      '<label for="senha">Senha</label>' +
      '<div class="input-with-icon">' +
      '<span class="input-icon">' + ICON_LOCK + '</span>' +
      '<input id="senha" name="senha" type="password" autocomplete="current-password" placeholder="Sua senha secreta" required />' +
      '<button type="button" class="toggle-password" id="toggle-password" aria-label="Mostrar senha">' + ICON_EYE + '</button>' +
      '</div>' +
      '</div>' +
      '<p class="error-message" id="error-message" hidden></p>' +
      '<button type="submit" class="btn btn-lg">Entrar →</button>' +
      '</form>' +
      '<button type="button" class="forgot-password-link" id="forgot-password">Esqueci minha senha</button>' +
      '<p class="forgot-password-hint" id="forgot-password-hint" hidden>Peça ajuda a um adulto para redefinir sua senha.</p>' +
      '<p class="demo-hint">Demonstração: lucas / maria / pedro / ana — senha <strong>1234</strong></p>' +
      '</div>' +
      '</div>' +
      '</main>';

    document.getElementById('login-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const login = document.getElementById('login').value.trim().toLowerCase();
      const senha = document.getElementById('senha').value;
      const student = StorageService.getStudentByLogin(login);
      const errorEl = document.getElementById('error-message');

      if (!student || student.senha !== senha) {
        errorEl.textContent = 'Login ou senha inválidos.';
        errorEl.hidden = false;
        return;
      }

      StudentSession.setCurrentStudentId(student.id);
      window.location.href = 'home.html';
    });

    document.getElementById('toggle-password').addEventListener('click', function () {
      const senhaInput = document.getElementById('senha');
      const showing = senhaInput.type === 'text';
      senhaInput.type = showing ? 'password' : 'text';
      this.innerHTML = showing ? ICON_EYE : ICON_EYE_OFF;
      this.setAttribute('aria-label', showing ? 'Mostrar senha' : 'Ocultar senha');
    });

    document.getElementById('forgot-password').addEventListener('click', () => {
      document.getElementById('forgot-password-hint').hidden = false;
    });
  }

  document.addEventListener('DOMContentLoaded', render);
})();
