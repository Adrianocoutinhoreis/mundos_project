(function () {
  async function render() {
    const studentId = StudentSession.requireLogin();
    if (!studentId) return;

    const app = document.getElementById('app');
    app.innerHTML = '<p class="loading-message">Carregando...</p>';

    const perfilAtivo = await FGIEngine.loadStudentProfile(studentId);
    const resultId = StudentSession.getLastResultId();
    const results = StorageService.getResultsByStudent(studentId);
    const result = results.find((r) => r.id === resultId) || results[results.length - 1];

    if (!result) {
      app.innerHTML =
        StudentNav.render(perfilAtivo.student) +
        '<main class="layout"><div class="card result-card">' +
        '<h1>Nenhum resultado ainda</h1>' +
        '<p>Jogue uma atividade para ver seu resultado aqui.</p>' +
        '<a class="btn" href="activities.html">Ver Atividades</a>' +
        '</div></main>';
      StudentNav.bindLogout();
      return;
    }

    app.innerHTML =
      StudentNav.render(perfilAtivo.student) +
      '<main class="layout">' +
      '<div class="card result-card">' +
      '<h1>' + (result.sucesso ? 'Muito bem!' : 'Bom trabalho!') + '</h1>' +
      '<p class="result-score">Pontuação: ' + (result.pontuacao != null ? result.pontuacao : '—') + '</p>' +
      '<p>Tentativas: ' + (result.tentativas != null ? result.tentativas : '—') + '</p>' +
      '<p>Tempo: ' + result.tempoSegundos + 's</p>' +
      '<div style="display:flex; gap:12px; margin-top:16px; flex-wrap: wrap; justify-content:center;">' +
      '<a class="btn" href="activities.html">Ver Atividades</a>' +
      '<a class="btn secondary" href="home.html">Início</a>' +
      '</div>' +
      '</div>' +
      '</main>';

    StudentNav.bindLogout();
  }

  document.addEventListener('DOMContentLoaded', render);
})();
