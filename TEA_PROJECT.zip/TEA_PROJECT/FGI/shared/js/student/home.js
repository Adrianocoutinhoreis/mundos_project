(function () {
  const SVG_PANDA_SOMA =
    '<svg viewBox="0 0 160 140" width="160" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">' +
    '<circle cx="42" cy="42" r="13" fill="#FF4B4B"/>' +
    '<path d="M42 27c2 0 4 2 4 4" stroke="#46A302" stroke-width="3" stroke-linecap="round"/>' +
    '<circle cx="80" cy="24" r="13" fill="#FF4B4B"/>' +
    '<path d="M80 9c2 0 4 2 4 4" stroke="#46A302" stroke-width="3" stroke-linecap="round"/>' +
    '<circle cx="118" cy="42" r="13" fill="#FF4B4B"/>' +
    '<path d="M118 27c2 0 4 2 4 4" stroke="#46A302" stroke-width="3" stroke-linecap="round"/>' +
    '<ellipse cx="80" cy="96" rx="28" ry="30" fill="#D9531E"/>' +
    '<ellipse cx="80" cy="98" rx="18" ry="20" fill="#FCE4C8"/>' +
    '<circle cx="80" cy="66" r="30" fill="#D9531E"/>' +
    '<path d="M52 46 Q44 33 60 41 Z" fill="#D9531E"/>' +
    '<path d="M54 47 Q48 37 58 43 Z" fill="#FFF"/>' +
    '<path d="M108 46 Q116 33 100 41 Z" fill="#D9531E"/>' +
    '<path d="M106 47 Q112 37 102 43 Z" fill="#FFF"/>' +
    '<ellipse cx="63" cy="74" rx="7" ry="5" fill="#FFF"/>' +
    '<ellipse cx="97" cy="74" rx="7" ry="5" fill="#FFF"/>' +
    '<circle cx="69" cy="63" r="4" fill="#3C3C3C"/>' +
    '<circle cx="91" cy="63" r="4" fill="#3C3C3C"/>' +
    '<circle cx="70" cy="61" r="1.5" fill="#FFF"/>' +
    '<circle cx="92" cy="61" r="1.5" fill="#FFF"/>' +
    '<ellipse cx="80" cy="68" rx="3" ry="2" fill="#3C3C3C"/>' +
    '<path d="M76 73 Q80 78 84 73" stroke="#3C3C3C" stroke-width="2" stroke-linecap="round" fill="none"/>' +
    '<path d="M106 96 C122 91 132 110 118 120 C108 124 98 110 106 96 Z" fill="#D9531E"/>' +
    '<path d="M50 82 Q38 66 46 56" stroke="#D9531E" stroke-width="11" stroke-linecap="round" fill="none"/>' +
    '<path d="M110 82 Q122 66 114 56" stroke="#D9531E" stroke-width="11" stroke-linecap="round" fill="none"/>' +
    '</svg>';

  const SVG_OWL_SUBTRACAO =
    '<svg viewBox="0 0 160 140" width="160" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">' +
    '<path d="M10 115 Q90 110 150 115" stroke="#8B5A2B" stroke-width="14" stroke-linecap="round"/>' +
    '<path d="M130 115 Q140 95 155 90" stroke="#8B5A2B" stroke-width="8" stroke-linecap="round"/>' +
    '<circle cx="145" cy="85" r="8" fill="#46A302"/>' +
    '<circle cx="155" cy="98" r="6" fill="#46A302"/>' +
    '<circle cx="35" cy="98" r="12" fill="#FF4B4B"/>' +
    '<path d="M35 84c2 0 4 2 4 4" stroke="#46A302" stroke-width="2.5" stroke-linecap="round"/>' +
    '<ellipse cx="85" cy="80" rx="28" ry="32" fill="#A0522D"/>' +
    '<ellipse cx="85" cy="88" rx="18" ry="20" fill="#F4A460"/>' +
    '<circle cx="73" cy="65" r="14" fill="#FFF"/>' +
    '<circle cx="97" cy="65" r="14" fill="#FFF"/>' +
    '<circle cx="73" cy="65" r="7" fill="#3C3C3C"/>' +
    '<circle cx="97" cy="65" r="7" fill="#3C3C3C"/>' +
    '<circle cx="71" cy="63" r="2.5" fill="#FFF"/>' +
    '<circle cx="95" cy="63" r="2.5" fill="#FFF"/>' +
    '<polygon points="85,73 80,82 90,82" fill="#FF8C00"/>' +
    '<ellipse cx="77" cy="110" rx="6" ry="3" fill="#FF8C00"/>' +
    '<ellipse cx="93" cy="110" rx="6" ry="3" fill="#FF8C00"/>' +
    '</svg>';

  const SVG_DEFAULT =
    '<svg viewBox="0 0 160 140" width="160" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">' +
    '<rect x="30" y="40" width="100" height="60" rx="20" fill="#1CB0F6"/>' +
    '<circle cx="60" cy="70" r="10" fill="#FFF"/>' +
    '<circle cx="100" cy="65" r="6" fill="#FFD700"/>' +
    '<circle cx="112" cy="75" r="6" fill="#58CC02"/>' +
    '</svg>';

  async function fetchGameManifest(gameId) {
    try {
      const response = await fetch('../games/' + gameId + '/manifest.json');
      if (!response.ok) return null;
      return response.json();
    } catch (e) {
      return null;
    }
  }

  async function render() {
    const studentId = StudentSession.requireLogin();
    if (!studentId) return;

    document.body.setAttribute('data-screen', 'student-home');

    const app = document.getElementById('app');
    app.innerHTML = '<p class="loading-message">Carregando a sua sala de jogos...</p>';

    const perfilAtivo = await FGIEngine.loadStudentProfile(studentId);
    const student = perfilAtivo.student;
    const results = StorageService.getResultsByStudent(studentId);
    const totalEstrelas = Gamification.totalEstrelas(results);
    const totalPontos = Gamification.totalPontos(results);

    const availableGames = window.GAME_CATALOG.filter((game) => perfilAtivo.jogosHabilitados.includes(game.id));
    const manifests = await Promise.all(availableGames.map((game) => fetchGameManifest(game.id)));

    // Render dos Cards em Carrossel
    const gameCardsHtml = manifests.length
      ? manifests
          .map((manifest, index) => {
            const game = availableGames[index];
            const nome = (manifest && manifest.nomeJogo) || game.nomeJogo;
            const descricao = (manifest && manifest.descricao) || 'Pratique de forma divertida!';
            
            let illustration = SVG_DEFAULT;
            let btnClass = 'duo-btn-green';
            
            if (game.id === 'soma') {
              illustration = '<img src="../games/assets/mascote/mascote01.png" alt="Jogo da Soma" />';
              btnClass = 'duo-btn-green';
            } else if (game.id === 'subtracao') {
              illustration = '<img src="../games/assets/mascote/soma_mascote.png" alt="Jogo da Subtração" />';
              btnClass = 'duo-btn-blue';
            }

            return (
              '<div class="duo-game-card">' +
              '<h2 class="duo-card-title">' + nome + '</h2>' +
              '<div class="duo-card-illustration">' + illustration + '</div>' +
              '<p class="duo-card-subtitle">' + descricao + '</p>' +
              '<a class="duo-btn-play ' + btnClass + '" href="game.html?jogo=' + game.id + '">Jogar</a>' +
              '</div>'
            );
          })
          .join('')
      : '<div class="duo-game-card"><p class="duo-card-subtitle">Nenhum jogo disponível no momento. Fale com seu professor.</p></div>';

    // Gerar Pílulas de Paginação
    const dotsCount = manifests.length || 1;
    let dotsHtml = '';
    for (let i = 0; i < dotsCount; i++) {
      dotsHtml += '<span class="duo-dot ' + (i === 0 ? 'active' : '') + '" data-index="' + i + '"></span>';
    }

    app.innerHTML =
      '<div class="duo-container">' +
      '<!-- Header Flutuante Integrado -->' +
      '<div class="duo-header-card">' +
      '<div class="duo-header-user">' +
      '<div class="duo-avatar">🐼</div>' +
      '<h1 class="duo-greeting">Olá, ' + student.nomeAluno + '!</h1>' +
      '</div>' +
      '<div class="duo-header-badges">' +
      '<span class="duo-badge">Atividades Concluídas: ' + results.length + ' 🏆</span>' +
      '<span class="duo-badge points-badge">' + totalPontos + ' Pontos 💯</span>' +
      '<span class="duo-badge stars-badge">' + totalEstrelas + ' Estrelas ⭐️</span>' +
      '<button class="duo-logout-btn" id="logout-btn" type="button" title="Sair do perfil">Sair</button>' +
      '</div>' +
      '</div>' +

      '<!-- Carrossel de Jogos -->' +
      '<div class="duo-carousel-wrapper">' +
      '<div class="duo-carousel-track" id="carousel-track">' +
      gameCardsHtml +
      '</div>' +
      '<div class="duo-carousel-dots" id="carousel-dots">' +
      dotsHtml +
      '</div>' +
      '</div>' +
      '</div>';

    // Eventos do Logout e Carrossel
    StudentNav.bindLogout();

    const track = document.getElementById('carousel-track');
    const dots = document.querySelectorAll('.duo-dot');

    if (track && dots.length > 0) {
      track.addEventListener('scroll', () => {
        const cardWidth = 418; // 390px + 28px gap
        const index = Math.round(track.scrollLeft / cardWidth);
        dots.forEach((dot, i) => {
          if (i === index) {
            dot.classList.add('active');
          } else {
            dot.classList.remove('active');
          }
        });
      });

      dots.forEach((dot) => {
        dot.addEventListener('click', () => {
          const index = parseInt(dot.getAttribute('data-index'), 10);
          const cardWidth = 418;
          track.scrollTo({ left: index * cardWidth, behavior: 'smooth' });
        });
      });
    }
  }

  document.addEventListener('DOMContentLoaded', render);
})();
