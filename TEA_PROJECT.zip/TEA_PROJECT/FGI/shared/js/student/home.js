(function () {
  const ICON_BOOK =
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>';
  const ICON_ROCKET =
    '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path></svg>';
  const ICON_PUZZLE =
    '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h3a2 2 0 1 1 0 4H4v3a2 2 0 1 0 4 0v-1h4v1a2 2 0 1 0 4 0v-3h3a2 2 0 1 0 0-4h-3V4a2 2 0 1 0-4 0v3H8V4a2 2 0 1 0-4 0z"></path></svg>';

  async function fetchGameManifest(gameId) {
    const response = await fetch('../games/' + gameId + '/manifest.json');
    if (!response.ok) return null;
    return response.json();
  }

  async function render() {
    const studentId = StudentSession.requireLogin();
    if (!studentId) return;

    const app = document.getElementById('app');
    app.innerHTML = '<p class="loading-message">Carregando...</p>';

    const perfilAtivo = await FGIEngine.loadStudentProfile(studentId);
    const student = perfilAtivo.student;
    const results = StorageService.getResultsByStudent(studentId);

    const availableGames = window.GAME_CATALOG.filter((game) => perfilAtivo.jogosHabilitados.includes(game.id));
    const manifests = await Promise.all(availableGames.map((game) => fetchGameManifest(game.id)));

    const ctaHref = availableGames.length ? 'game.html?jogo=' + availableGames[0].id : 'activities.html';

    const gameCards = manifests.length
      ? manifests
          .map((manifest, index) => {
            const game = availableGames[index];
            const nome = (manifest && manifest.nome) || game.nome;
            const descricao = (manifest && manifest.descricao) || 'Toque para começar.';
            const icone = (manifest && manifest.icone) || '🎮';
            const corTema = (manifest && manifest.corTema) || 'var(--color-primary)';
            return (
              '<div class="game-carousel-item">' +
              '<a class="game-card" href="game.html?jogo=' + game.id + '">' +
              '<span class="game-card-icon" style="background:' + corTema + '33;">' + icone + '</span>' +
              '<h3>' + nome + '</h3>' +
              '<p>' + descricao + '</p>' +
              '<span class="btn game-card-play">Jogar</span>' +
              '</a>' +
              '</div>'
            );
          })
          .join('')
      : '<div class="progress-card"><p>Nenhum jogo disponível para o seu perfil ainda. Fale com seu professor.</p></div>';

    app.innerHTML =
      StudentNav.render(student) +
      '<div class="home-layout">' +
      '<aside class="home-sidebar">' +
      '<div class="sidebar-greeting-card">' +
      '<span class="sidebar-avatar">🙂</span>' +
      '<div>' +
      '<p class="sidebar-greeting-name">Olá, ' + student.nome + '!</p>' +
      '<p class="sidebar-greeting-sub">Pronto para hoje?</p>' +
      '</div>' +
      '</div>' +
      '<a class="btn sidebar-cta" href="' + ctaHref + '">' + ICON_ROCKET + ' Começar a Jogar</a>' +
      '<nav class="sidebar-nav">' +
      '<a class="sidebar-nav-item active" href="activities.html">' + ICON_BOOK + ' Minha Jornada</a>' +
      '</nav>' +
      '</aside>' +
      '<main class="home-main">' +
      '<h1>Olá, ' + student.nome + '!</h1>' +
      '<p class="home-subtitle">Hoje é um dia maravilhoso para aprender algo novo. Vamos começar com uma atividade divertida?</p>' +
      '<div class="progress-card">' +
      '<h2>Meu Progresso</h2>' +
      '<p class="progress-caption">Você está indo muito bem!</p>' +
      '<p class="progress-count">' + results.length + ' atividade(s) concluída(s)</p>' +
      '</div>' +
      '<div class="games-section-header">' +
      '<h2>' + ICON_PUZZLE + ' Jogos</h2>' +
      '<a class="ver-todos-link" href="activities.html">Ver todos</a>' +
      '</div>' +
      '<div class="games-carousel">' + gameCards + '</div>' +
      '</main>' +
      '</div>';

    StudentNav.bindLogout();
  }

  document.addEventListener('DOMContentLoaded', render);
})();
