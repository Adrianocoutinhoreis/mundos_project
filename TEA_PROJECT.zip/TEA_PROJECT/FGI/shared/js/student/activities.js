(function () {
  async function render() {
    const studentId = StudentSession.requireLogin();
    if (!studentId) return;

    const app = document.getElementById('app');
    app.innerHTML = '<p class="loading-message">Carregando...</p>';

    const perfilAtivo = await FGIEngine.loadStudentProfile(studentId);
    const student = perfilAtivo.student;
    const availableGames = window.GAME_CATALOG.filter((game) => perfilAtivo.jogosHabilitados.includes(game.id));

    const cards = availableGames.length
      ? availableGames
          .map(
            (game) =>
              '<a class="action-card" href="game.html?jogo=' +
              game.id +
              '"><div class="card"><h2>' +
              game.nomeJogo +
              '</h2><p>Toque para começar.</p></div></a>'
          )
          .join('')
      : '<div class="card"><p>Nenhum jogo disponível para o seu perfil ainda. Fale com seu professor.</p></div>';

    app.innerHTML =
      StudentNav.render(student) +
      '<main class="layout">' +
      '<h1>Atividades</h1>' +
      '<div class="grid cols-2">' + cards + '</div>' +
      '</main>';

    StudentNav.bindLogout();
  }

  document.addEventListener('DOMContentLoaded', render);
})();
