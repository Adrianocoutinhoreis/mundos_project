(function (global) {
  // Itens do menu lateral. Segue a referência (Painel, Alunos, Jogos, Relatórios,
  // Configurações). "Perfil de Apoio" não é item de menu — é acessado pelo card do
  // Painel. "Alunos" aponta, por ora, para a tela de gerenciamento existente; uma
  // tela dedicada com todos os alunos será criada depois.
  const ITEMS = [
    { id: 'dashboard', label: 'Painel', href: 'dashboard.html', icon: 'grid', title: 'Painel do Professor' },
    { id: 'students', label: 'Alunos', href: 'students.html', icon: 'users', title: 'Alunos' },
    { id: 'games', label: 'Jogos', href: 'games.html', icon: 'gamepad', title: 'Jogos' },
    { id: 'reports', label: 'Relatórios', href: 'reports.html', icon: 'chart', title: 'Relatórios' },
    { id: 'settings', label: 'Configurações', href: 'settings.html', icon: 'gear', title: 'Configurações' },
  ];

  // Título da barra de topo para telas que não estão no menu (ex.: Perfil de Apoio).
  const EXTRA_TITLES = {
    profiles: 'Perfil de Apoio',
  };

  const ICONS = {
    grid:
      '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
    users:
      '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    gamepad:
      '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="6" y1="11" x2="10" y2="11"/><line x1="8" y1="9" x2="8" y2="13"/><line x1="15" y1="12" x2="15.01" y2="12"/><line x1="18" y1="10" x2="18.01" y2="10"/><rect x="2" y="6" width="20" height="12" rx="4"/></svg>',
    chart:
      '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="20" x2="4" y2="10"/><line x1="10" y1="20" x2="10" y2="4"/><line x1="16" y1="20" x2="16" y2="14"/><line x1="20" y1="20" x2="20" y2="8"/></svg>',
    gear:
      '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
    logout:
      '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
    cap:
      '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c0 1 2.5 3 6 3s6-2 6-3v-5"/></svg>',
    search:
      '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    user:
      '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  };

  function sidebar(activeId) {
    const links = ITEMS.map(
      (item) =>
        '<li><a href="' +
        item.href +
        '"' +
        (item.id === activeId ? ' class="active" aria-current="page"' : '') +
        '><span class="nav-icon">' +
        ICONS[item.icon] +
        '</span><span class="nav-label">' +
        item.label +
        '</span></a></li>'
    ).join('');

    return (
      '<aside class="teacher-sidebar">' +
      '<a class="sidebar-brand" href="dashboard.html">' +
      '<span class="brand-logo">' + ICONS.cap + '</span>' +
      '<span class="brand-text"><span class="brand-name">FGI</span>' +
      '<span class="brand-sub">Portal do Professor</span></span>' +
      '</a>' +
      '<nav class="sidebar-nav" aria-label="Menu principal"><ul>' + links + '</ul></nav>' +
      '<a class="sidebar-logout" href="../student/login.html">' +
      '<span class="nav-icon">' + ICONS.logout + '</span><span class="nav-label">Sair</span>' +
      '</a>' +
      '</aside>'
    );
  }

  function topbar(activeId, opts) {
    const options = opts || {};
    const known = ITEMS.find((i) => i.id === activeId);
    const title = options.title || (known && known.title) || EXTRA_TITLES[activeId] || 'Portal do Professor';

    const search = options.search
      ? '<form class="topbar-search" role="search" onsubmit="return false;">' +
        '<span class="search-icon">' + ICONS.search + '</span>' +
        '<input type="search" id="' + (options.searchId || 'topbar-search') + '" ' +
        'placeholder="' + (options.searchPlaceholder || 'Buscar Jogos') + '" ' +
        'aria-label="Buscar" />' +
        '</form>'
      : '<div class="topbar-spacer"></div>';

    return (
      '<header class="teacher-topbar">' +
      '<h2 class="topbar-title">' + title + '</h2>' +
      search +
      '<div class="topbar-user">' +
      '<div class="topbar-user-info"><span class="topbar-user-name">Professor(a)</span>' +
      '<span class="topbar-user-sub">Portal FGI</span></div>' +
      '<div class="topbar-avatar">' + ICONS.user + '</div>' +
      '</div>' +
      '</header>'
    );
  }

  // Retorna a estrutura de navegação (sidebar + topbar). As páginas continuam
  // concatenando seu próprio <main class="layout"> em seguida — o CSS posiciona
  // a sidebar/topbar como fixas e recua o conteúdo.
  function render(activeId, opts) {
    return sidebar(activeId) + topbar(activeId, opts);
  }

  global.TeacherNav = { render, ICONS };
})(window);
