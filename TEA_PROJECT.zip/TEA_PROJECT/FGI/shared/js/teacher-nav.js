(function (global) {
  const ITEMS = [
    { id: 'dashboard', label: 'Painel', href: 'dashboard.html' },
    { id: 'profiles', label: 'Perfis de Apoio', href: 'profiles.html' },
    { id: 'students', label: 'Alunos', href: 'students.html' },
    { id: 'games', label: 'Jogos Disponíveis', href: 'games.html' },
    { id: 'reports', label: 'Resultados', href: 'reports.html' },
    { id: 'settings', label: 'Configurações', href: 'settings.html' },
  ];

  function render(activeId) {
    const links = ITEMS.map(
      (item) =>
        '<li><a href="' +
        item.href +
        '"' +
        (item.id === activeId ? ' class="active" aria-current="page"' : '') +
        '>' +
        item.label +
        '</a></li>'
    ).join('');
    return (
      '<nav class="teacher-nav"><div class="layout">' +
      '<span class="brand">FGI · Portal do Professor</span>' +
      '<ul>' +
      links +
      '</ul>' +
      '</div></nav>'
    );
  }

  global.TeacherNav = { render };
})(window);
