// Catálogo de jogos independentes disponíveis em games/. Cada jogo é isolado do FGI
// e só recebe configurações adaptativas + devolve resultados (ver arquitetura.md).
window.GAME_CATALOG = [{ id: 'soma', nome: 'Soma' }];
