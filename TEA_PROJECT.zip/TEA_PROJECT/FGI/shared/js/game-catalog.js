// Catálogo de jogos independentes disponíveis em games/. Cada jogo é isolado do FGI
// e só recebe configurações adaptativas + devolve resultados (ver arquitetura.md).
//
// Além de id/nomeJogo, o catálogo carrega metadados LEVES (disciplina, habilidades e
// perfis compatíveis) para permitir busca/filtro instantâneos na seleção de jogos por
// perfil — sem precisar baixar todos os manifest.json. Mantenha estes campos em sincronia
// com o manifest.json de cada jogo (os manifests seguem sendo a fonte completa).
window.GAME_CATALOG = [
  {
    id: 'soma',
    nomeJogo: 'Jogo da Soma',
    disciplina: 'matematica',
    icone: '🐢',
    cor: '#55a08a',
    habilidades: ['contagem', 'soma', 'raciocinio-logico'],
    perfilCompativel: ['tipico', 'tea_1', 'tea_2', 'tea_3', 'tdah', 'dislexia'],
  },
  {
    id: 'subtracao',
    nomeJogo: 'Jogo da Subtração',
    disciplina: 'matematica',
    icone: '🦉',
    cor: '#7a6ab0',
    habilidades: ['contagem', 'subtracao', 'raciocinio-logico'],
    perfilCompativel: ['tipico', 'tea_1', 'tea_2', 'tea_3', 'tdah', 'dislexia'],
  },
];

// Rótulos legíveis das disciplinas (para agrupar/filtrar). Acrescente aqui conforme
// novas disciplinas de jogos forem adicionadas.
window.GAME_DISCIPLINAS = {
  matematica: 'Matemática',
  portugues: 'Português',
  ciencias: 'Ciências',
  socioemocional: 'Socioemocional',
  motor: 'Motor',
};
