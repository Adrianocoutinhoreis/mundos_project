(function (global) {
  const STORAGE_PREFIX = 'fgi:';
  const KEYS = {
    configPerfis: STORAGE_PREFIX + 'configPerfis',
    alunos: STORAGE_PREFIX + 'alunos',
    resultados: STORAGE_PREFIX + 'resultados',
    configGeral: STORAGE_PREFIX + 'configGeral',
  };

  // Chaves do esquema antigo (em inglês), usadas só pela migração automática.
  const CHAVES_ANTIGAS = {
    configPerfis: STORAGE_PREFIX + 'profiles',
    alunos: STORAGE_PREFIX + 'students',
    resultados: STORAGE_PREFIX + 'gameResults',
    configGeral: STORAGE_PREFIX + 'settings',
  };

  function readJSON(key, fallback) {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    try {
      return JSON.parse(raw);
    } catch (err) {
      console.error('StorageService: falha ao ler ' + key, err);
      return fallback;
    }
  }

  function writeJSON(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function generateId(prefix) {
    return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  // Dados iniciais de demonstração. Perfis pedagógicos completos ficam em profiles/*.json;
  // aqui só fica a configuração do professor (jogos habilitados/ajustes) sobre cada perfil.
  function demoData() {
    const niveis = ['tipico', 'tea_1', 'tea_2', 'tea_3', 'tdah', 'dislexia'];
    const configPerfis = {};
    niveis.forEach((nivelDeApoio) => {
      configPerfis[nivelDeApoio] = { nivelDeApoio, jogosHabilitados: ['soma', 'subtracao'], ajustes: {} };
    });

    return {
      configPerfis,
      alunos: [
        { id: 'std_lucas', nomeAluno: 'Lucas', login: 'lucas', senha: '1234', nivelDeApoio: 'tea_2' },
        { id: 'std_maria', nomeAluno: 'Maria', login: 'maria', senha: '1234', nivelDeApoio: 'tipico' },
        { id: 'std_pedro', nomeAluno: 'Pedro', login: 'pedro', senha: '1234', nivelDeApoio: 'tdah' },
        { id: 'std_ana', nomeAluno: 'Ana', login: 'ana', senha: '1234', nivelDeApoio: 'dislexia' },
      ],
      resultados: [],
      configGeral: {
        parametrosGlobais: {
          tutorialObrigatorio: true,
        },
      },
    };
  }

  // Migração ÚNICA e NÃO-destrutiva: se as chaves novas ainda não existem mas as antigas
  // existem, copia os dados renomeando os campos (inglês -> português). As chaves antigas
  // não são apagadas, então nada é perdido se for preciso voltar atrás.
  function migrarEsquemaAntigo() {
    if (localStorage.getItem(KEYS.alunos) === null && localStorage.getItem(CHAVES_ANTIGAS.alunos) !== null) {
      const antigos = readJSON(CHAVES_ANTIGAS.alunos, []);
      writeJSON(
        KEYS.alunos,
        antigos.map((a) => ({
          id: a.id,
          nomeAluno: a.nome,
          login: a.login,
          senha: a.senha,
          nivelDeApoio: a.perfilId,
        }))
      );
    }

    if (localStorage.getItem(KEYS.resultados) === null && localStorage.getItem(CHAVES_ANTIGAS.resultados) !== null) {
      const alunosAntigos = readJSON(CHAVES_ANTIGAS.alunos, []);
      const nomePorId = {};
      alunosAntigos.forEach((a) => {
        nomePorId[a.id] = a.nome;
      });
      const antigos = readJSON(CHAVES_ANTIGAS.resultados, []);
      writeJSON(
        KEYS.resultados,
        antigos.map((r) => {
          const novo = Object.assign({}, r);
          novo.alunoId = r.studentId;
          novo.nomeAluno = nomePorId[r.studentId] || r.studentId;
          novo.jogoId = r.gameId;
          novo.nivelDeApoio = r.perfilId;
          delete novo.studentId;
          delete novo.gameId;
          delete novo.perfilId;
          return novo;
        })
      );
    }

    if (localStorage.getItem(KEYS.configPerfis) === null && localStorage.getItem(CHAVES_ANTIGAS.configPerfis) !== null) {
      const antigos = readJSON(CHAVES_ANTIGAS.configPerfis, {});
      const novo = {};
      Object.keys(antigos).forEach((chave) => {
        const c = antigos[chave] || {};
        novo[chave] = {
          nivelDeApoio: c.perfilId || chave,
          jogosHabilitados: c.jogosHabilitados || [],
          ajustes: c.overrides || {},
        };
      });
      writeJSON(KEYS.configPerfis, novo);
    }

    if (localStorage.getItem(KEYS.configGeral) === null && localStorage.getItem(CHAVES_ANTIGAS.configGeral) !== null) {
      writeJSON(KEYS.configGeral, readJSON(CHAVES_ANTIGAS.configGeral, {}));
    }
  }

  function seedIfEmpty() {
    const seed = demoData();
    if (localStorage.getItem(KEYS.configPerfis) === null) writeJSON(KEYS.configPerfis, seed.configPerfis);
    if (localStorage.getItem(KEYS.alunos) === null) writeJSON(KEYS.alunos, seed.alunos);
    if (localStorage.getItem(KEYS.resultados) === null) writeJSON(KEYS.resultados, seed.resultados);
    if (localStorage.getItem(KEYS.configGeral) === null) writeJSON(KEYS.configGeral, seed.configGeral);
  }

  function init() {
    migrarEsquemaAntigo();
    seedIfEmpty();
  }

  function resetDemoData() {
    const seed = demoData();
    writeJSON(KEYS.configPerfis, seed.configPerfis);
    writeJSON(KEYS.alunos, seed.alunos);
    writeJSON(KEYS.resultados, seed.resultados);
    writeJSON(KEYS.configGeral, seed.configGeral);
    return seed;
  }

  const StorageService = {
    init,
    resetDemoData,

    // configPerfis (configuração do professor sobre cada perfil/nível de apoio)
    getProfilesConfig() {
      return readJSON(KEYS.configPerfis, {});
    },
    getProfileConfig(nivelDeApoio) {
      const all = readJSON(KEYS.configPerfis, {});
      return all[nivelDeApoio] || null;
    },
    saveProfileConfig(nivelDeApoio, config) {
      const all = readJSON(KEYS.configPerfis, {});
      all[nivelDeApoio] = Object.assign({ nivelDeApoio }, all[nivelDeApoio], config);
      writeJSON(KEYS.configPerfis, all);
      return all[nivelDeApoio];
    },

    // alunos
    getStudents() {
      return readJSON(KEYS.alunos, []);
    },
    getStudentByLogin(login) {
      return this.getStudents().find((s) => s.login === login) || null;
    },
    getStudentById(id) {
      return this.getStudents().find((s) => s.id === id) || null;
    },
    saveStudent(student) {
      const alunos = this.getStudents();
      const index = alunos.findIndex((s) => s.id === student.id);
      const record = index >= 0 ? Object.assign({}, alunos[index], student) : Object.assign({ id: generateId('std') }, student);
      if (index >= 0) {
        alunos[index] = record;
      } else {
        alunos.push(record);
      }
      writeJSON(KEYS.alunos, alunos);
      return record;
    },
    deleteStudent(id) {
      const alunos = this.getStudents().filter((s) => s.id !== id);
      writeJSON(KEYS.alunos, alunos);
    },

    // resultados
    getGameResults() {
      return readJSON(KEYS.resultados, []);
    },
    getResultsByStudent(alunoId) {
      return this.getGameResults().filter((r) => r.alunoId === alunoId);
    },
    addGameResult(result) {
      const resultados = this.getGameResults();
      // `enviado: false` marca o resultado como ainda não sincronizado com a
      // plataforma externa (ver educandus-sync.js).
      const entry = Object.assign({ id: generateId('res'), enviado: false }, result);
      resultados.push(entry);
      writeJSON(KEYS.resultados, resultados);
      // Ponto ÚNICO de emissão: dispara 1 envio por execução (fire-and-forget).
      // Se o módulo não estiver carregado ou não houver endpoint, o resultado
      // fica pendente e é reenviado depois por EducandusSync.sincronizarPendentes().
      if (global.EducandusSync) {
        global.EducandusSync.enviar(entry);
      }
      return entry;
    },
    // Marca um resultado como já enviado à plataforma externa (idempotente).
    markResultSent(id) {
      const resultados = this.getGameResults();
      const registro = resultados.find((r) => r.id === id);
      if (registro && !registro.enviado) {
        registro.enviado = true;
        writeJSON(KEYS.resultados, resultados);
      }
      return registro || null;
    },
    // Resultados ainda não sincronizados (usado pelo reenvio em lote).
    getPendingResults() {
      return this.getGameResults().filter((r) => !r.enviado);
    },

    // configGeral (parâmetros globais ajustados pelo professor)
    getSettings() {
      return readJSON(KEYS.configGeral, {});
    },
    saveSettings(settings) {
      writeJSON(KEYS.configGeral, settings);
      return settings;
    },
  };

  StorageService.init();

  global.StorageService = StorageService;
})(window);
