(function (global) {
  const STORAGE_PREFIX = 'fgi:';
  const KEYS = {
    profiles: STORAGE_PREFIX + 'profiles',
    students: STORAGE_PREFIX + 'students',
    gameResults: STORAGE_PREFIX + 'gameResults',
    settings: STORAGE_PREFIX + 'settings',
  };

  function readJSON(key, fallback) {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    try {
      return JSON.parse(raw);
    } catch (err) {
      console.error('StorageService: falha ao ler ' + key, err);
      return fallback;
    }
  }

  function writeJSON(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function generateId(prefix) {
    return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  // Dados iniciais de demonstração. Perfis pedagógicos completos ficam em profiles/*.json;
  // aqui só fica a configuração do professor (jogos habilitados/overrides) sobre cada perfil.
  function demoData() {
    const perfis = ['tipico', 'tea_1', 'tea_2', 'tea_3', 'tdah', 'dislexia'];
    const profiles = {};
    perfis.forEach((perfilId) => {
      profiles[perfilId] = { perfilId, jogosHabilitados: ['soma'], overrides: {} };
    });

    return {
      profiles,
      students: [
        { id: 'std_lucas', nome: 'Lucas', login: 'lucas', senha: '1234', perfilId: 'tea_2' },
        { id: 'std_maria', nome: 'Maria', login: 'maria', senha: '1234', perfilId: 'tipico' },
        { id: 'std_pedro', nome: 'Pedro', login: 'pedro', senha: '1234', perfilId: 'tdah' },
        { id: 'std_ana', nome: 'Ana', login: 'ana', senha: '1234', perfilId: 'dislexia' },
      ],
      gameResults: [],
      settings: {
        parametrosGlobais: {
          tutorialObrigatorio: true,
        },
      },
    };
  }

  function seedIfEmpty() {
    const seed = demoData();
    if (localStorage.getItem(KEYS.profiles) === null) writeJSON(KEYS.profiles, seed.profiles);
    if (localStorage.getItem(KEYS.students) === null) writeJSON(KEYS.students, seed.students);
    if (localStorage.getItem(KEYS.gameResults) === null) writeJSON(KEYS.gameResults, seed.gameResults);
    if (localStorage.getItem(KEYS.settings) === null) writeJSON(KEYS.settings, seed.settings);
  }

  function resetDemoData() {
    const seed = demoData();
    writeJSON(KEYS.profiles, seed.profiles);
    writeJSON(KEYS.students, seed.students);
    writeJSON(KEYS.gameResults, seed.gameResults);
    writeJSON(KEYS.settings, seed.settings);
    return seed;
  }

  const StorageService = {
    init: seedIfEmpty,
    resetDemoData,

    // profiles (configuração do professor sobre cada perfil de apoio)
    getProfilesConfig() {
      return readJSON(KEYS.profiles, {});
    },
    getProfileConfig(perfilId) {
      const all = readJSON(KEYS.profiles, {});
      return all[perfilId] || null;
    },
    saveProfileConfig(perfilId, config) {
      const all = readJSON(KEYS.profiles, {});
      all[perfilId] = Object.assign({ perfilId }, all[perfilId], config);
      writeJSON(KEYS.profiles, all);
      return all[perfilId];
    },

    // students
    getStudents() {
      return readJSON(KEYS.students, []);
    },
    getStudentByLogin(login) {
      return this.getStudents().find((s) => s.login === login) || null;
    },
    getStudentById(id) {
      return this.getStudents().find((s) => s.id === id) || null;
    },
    saveStudent(student) {
      const students = this.getStudents();
      const index = students.findIndex((s) => s.id === student.id);
      const record = index >= 0 ? Object.assign({}, students[index], student) : Object.assign({ id: generateId('std') }, student);
      if (index >= 0) {
        students[index] = record;
      } else {
        students.push(record);
      }
      writeJSON(KEYS.students, students);
      return record;
    },
    deleteStudent(id) {
      const students = this.getStudents().filter((s) => s.id !== id);
      writeJSON(KEYS.students, students);
    },

    // gameResults
    getGameResults() {
      return readJSON(KEYS.gameResults, []);
    },
    getResultsByStudent(studentId) {
      return this.getGameResults().filter((r) => r.studentId === studentId);
    },
    addGameResult(result) {
      const results = this.getGameResults();
      const entry = Object.assign({ id: generateId('res') }, result);
      results.push(entry);
      writeJSON(KEYS.gameResults, results);
      return entry;
    },

    // settings (parâmetros globais ajustados pelo professor)
    getSettings() {
      return readJSON(KEYS.settings, {});
    },
    saveSettings(settings) {
      writeJSON(KEYS.settings, settings);
      return settings;
    },
  };

  StorageService.init();

  global.StorageService = StorageService;
})(window);
