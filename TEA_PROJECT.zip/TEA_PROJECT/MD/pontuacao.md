# Sistema de Pontuação e Estrelas — FGI

Documento de referência do esquema atual de pontuação, estrelas e níveis de
proficiência. A **fonte única da verdade** de todos os limites e valores é o
arquivo [`shared/js/gamification.js`](../FGI/shared/js/gamification.js) — nenhum
outro arquivo deve repetir os números `80`/`50`, `100`/`300`/`500`.

---

## Conceitos

O sistema trabalha com três grandezas, todas derivadas de uma única medida:

| Conceito | O que é | Faixa de valores |
| --- | --- | --- |
| **Pontuação** (`pontuacao`) | % de acerto na **primeira tentativa**. É o único valor gravado. | 0 a 100 |
| **Faixa** | Nível de desempenho: mínimo / médio / máximo. Derivado da pontuação. | 3 níveis |
| **Pontos** | Valor de recompensa da faixa. Derivado, nunca gravado. | 100 / 300 / 500 |
| **Estrelas** | Selo visual da faixa. Derivado, nunca gravado. | 1 / 2 / 3 |
| **Proficiência** | Rótulo pedagógico para o professor, a partir da **média** das pontuações. | 3 níveis |

> **Princípio de projeto:** só a `pontuacao` (% de acerto) é persistida. Pontos,
> estrelas e proficiência são **calculados na hora** a partir dela. Assim, mudar
> as recompensas não exige migração de dados e os resultados antigos continuam
> válidos.

---

## Tabela de faixas (fonte única)

Definida em `gamification.js` na constante `FAIXAS`:

| Faixa | Acerto na 1ª tentativa | Pontos | Estrelas | Rótulo (aluno) | Proficiência (professor) |
| --- | --- | --- | --- | --- | --- |
| **máximo** | ≥ 80% (7–8 de 8) | **500** | ⭐⭐⭐ | "Excelente!" | Proficiente ("Acima") |
| **médio** | 50–79% (4–6 de 8) | **300** | ⭐⭐ | "Muito bem!" | Inicial ("No Nível") |
| **mínimo** | < 50% (0–3 de 8) | **100** | ⭐ | "Bom começo!" | Familiar ("Abaixo") |

Como toda atividade tem 8 perguntas fixas, a correspondência acertos → faixa é:

| Acertos de 1ª (de 8) | Pontuação | Faixa | Pontos | Estrelas |
| --- | --- | --- | --- | --- |
| 8 | 100 | máximo | 500 | ⭐⭐⭐ |
| 7 | 88 | máximo | 500 | ⭐⭐⭐ |
| 6 | 75 | médio | 300 | ⭐⭐ |
| 5 | 63 | médio | 300 | ⭐⭐ |
| 4 | 50 | médio | 300 | ⭐⭐ |
| 3 | 38 | mínimo | 100 | ⭐ |
| 2 | 25 | mínimo | 100 | ⭐ |
| 1 | 13 | mínimo | 100 | ⭐ |
| 0 | 0 | mínimo | 100 | ⭐ |

> **Piso de 1 estrela / 100 pontos:** mesmo com 0 acertos, a criança nunca fica
> com zero. É intencional e alinhado à filosofia do projeto (erro nunca é
> punido).

---

## Fluxo completo da pontuação

```
Jogo (iframe)              Host do jogo            Armazenamento         Telas
soma / subtracao           student/game.js         storage-service.js
──────────────────         ─────────────────       ─────────────────     ───────────────
conta acertos de 1ª tent.
  │
  └─ postMessage ─────────▶ pontuacao =
     { acertos, erros,        round(acertos/8*100)
       totalPerguntas,        │
       nivel }                └─ session.finish() ─▶ addGameResult() ────▶ result.html
                                                     (localStorage)         home.html
                                                                            reports.html
```

### 1. Jogo — `games/soma/script.js`, `games/subtracao/script.js`
- 8 perguntas fixas (`TOTAL_PERGUNTAS = 8`).
- Conta `acertosPrimeira` (acertos **sem errar antes**) e `erros`.
- Ao terminar, envia ao host:
  `postMessage({ type: 'JOGO_CONCLUIDO', acertos, erros, totalPerguntas: 8, nivel })`.
- Mostra na tela final **1 a 3 estrelas**, com as mesmas faixas (replicadas
  localmente porque o jogo roda isolado em iframe e não acessa `gamification.js`).
- O jogo **não** calcula pontuação nem conhece aluno/professor.

### 2. Host — `shared/js/student/game.js`
Recebe a mensagem e calcula:

```js
const total      = data.totalPerguntas || data.acertos + data.erros; // 8
const pontuacao  = total ? Math.round((data.acertos / total) * 100) : 0;
const tentativas = data.acertos + data.erros;
const sucesso    = data.erros === 0;
```

Chama `session.finish(...)` → grava via `StorageService.addGameResult`.

### 3. Armazenamento — `shared/js/storage-service.js`
Cada resultado gravado em `localStorage` (chave `fgi:resultados`) tem:

| Campo | Origem |
| --- | --- |
| `id` | gerado |
| `alunoId`, `nomeAluno`, `jogoId`, `nivelDeApoio` | perfil ativo |
| `pontuacao` | % de acerto (0–100) |
| `escore` | `{ atual, minima: 0, maxima: 100 }` — escore auto-descritivo p/ integração externa (`atual` = `pontuacao`) |
| `tentativas` | acertos + erros |
| `sucesso` | `true` se zero erros |
| `tempoSegundos`, `concluidoEm` | sessão |
| `detalhes` | texto "Acertos: X de 8 (nível N)" |

### 4. Telas que consomem
- **Resultado** (`student/result.js`): título = rótulo da faixa, estrelas (1–3),
  "X pontos" e as linhas de tentativas/tempo. Usa `Gamification.faixaPorPontuacao`.
- **Home** (`student/home.js`): badges "Atividades Concluídas", **"💯 Pontos"**
  (`Gamification.totalPontos`) e **"⭐ Estrelas"** (`Gamification.totalEstrelas`).
- **Relatório do professor** (`teacher/reports.js`): média das pontuações →
  `Gamification.proficienciaPorMedia`.

---

## API do módulo `gamification.js`

| Função | Retorno |
| --- | --- |
| `faixaPorPontuacao(pontuacao)` | objeto da faixa (`nivel`, `estrelas`, `pontos`, `rotulo`, `proficiencia`) |
| `estrelasPorPontuacao(pontuacao)` | 1, 2 ou 3 |
| `pontosPorPontuacao(pontuacao)` | 100, 300 ou 500 |
| `totalEstrelas(resultados)` | soma das estrelas de todos os resultados |
| `totalPontos(resultados)` | soma dos pontos de todos os resultados |
| `proficienciaPorMedia(media)` | `{ texto, className, titulo }` para o badge do professor |

---

## O que é medido (e o que não é)

- A pontuação mede **proficiência**, não conclusão: como o jogo deixa tentar de
  novo até acertar, a criança sempre completa; o que varia é quantas ela acertou
  **de primeira**.
- `tentativas` = acertos de 1ª + total de erros (não é o número de perguntas).
  Ex.: 6 acertos de primeira e 3 erros no total → `tentativas = 9`.
- `sucesso` (zero erros) é gravado, mas hoje **não** influencia pontos/estrelas —
  quem define a faixa é só a pontuação.

---

## Como alterar as regras

Praticamente tudo se muda em um só lugar — a constante `FAIXAS` em
`gamification.js`:

- **Valores de pontos** → campo `pontos` de cada faixa.
- **Limites das faixas** → campo `minAcerto`.
- **Rótulos / estrelas / textos de proficiência** → campos da faixa.

**Exceção:** os limites das faixas também estão replicados nas telas finais de
`games/soma/script.js` e `games/subtracao/script.js` (linha da
`estrelasConquistadas`), porque os jogos rodam isolados em iframe. Se mudar os
limites em `gamification.js`, atualize também esses dois pontos.
