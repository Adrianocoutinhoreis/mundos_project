# 00_PRODUCT_VISION.md

# FGI Learning Platform

## Visão do Produto

O FGI é uma plataforma de aprendizagem adaptativa baseada em jogos acessíveis e inclusivos.

O sistema possui dois ambientes independentes:

* Portal do Professor
* Portal do Aluno

Os jogos são executados pelo FGI Game Engine.

---

## Filosofia do Projeto

O FGI não é um conjunto de jogos.

O FGI é um motor de adaptação pedagógica que utiliza jogos como ferramenta de aprendizagem.

Os jogos são módulos independentes conectados ao motor principal.

---

## Portal do Professor

Responsável por:

* Gerenciar perfis de apoio;
* Cadastrar alunos e associar cada um a um perfil de apoio;
* Disponibilizar jogos para determinados perfis;
* Visualizar resultados e progresso;
* Ajustar parâmetros globais dos perfis.

O professor não configura ajustes adaptativos aluno por aluno — quem recebe essas configurações é o perfil, não o aluno individualmente.

O professor configura os perfis pedagógicos. Cadastrar um aluno (login, senha, perfil associado) é uma ação administrativa separada, feita uma vez por aluno.

---

## Perfis de Apoio

Implementados no protótipo atual:

* Aluno Típico
* TEA Nível 1
* TEA Nível 2
* TEA Nível 3
* TDAH
* Dislexia

Discalculia e Deficiência Intelectual foram removidos do protótipo por agora — podem ser adicionados depois seguindo o mesmo esquema.

Cada perfil possui configurações adaptativas próprias.

---

## Portal do Aluno

Cada aluno possui:

* Login
* Senha
* Perfil de Apoio associado

Ao acessar a plataforma, o sistema identifica automaticamente o perfil do aluno e aplica as adaptações necessárias.

O aluno não precisa configurar nada manualmente.

O aluno nunca vê o nome do próprio perfil de apoio na tela (ex.: "TEA Nível 2") — só sente o efeito das adaptações. O rótulo do perfil é informação de gestão pedagógica, não algo para expor à criança.

---

## Exemplo

Lucas

Perfil:
TEA Nível 2

O sistema automaticamente aplica:

* Tempo ilimitado;
* Redução de estímulos visuais;
* Feedback frequente;
* Sons reduzidos;
* Interface simplificada.

---

## Objetivo do Protótipo

Demonstrar visualmente:

Professor configura perfil

↓

Aluno realiza login

↓

Sistema adapta automaticamente o jogo

↓

Aluno joga

↓

Resultado é apresentado
