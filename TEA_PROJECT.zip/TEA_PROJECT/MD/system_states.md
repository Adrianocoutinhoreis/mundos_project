# 02_SYSTEM_STATES.md

# Estados do Sistema

## Fluxo do Professor

Dashboard

↓

Perfis de Apoio

↓

Selecionar Perfil

↓

Configurar Jogos Disponíveis

↓

Salvar Configuração

"Configurar Jogos Disponíveis" é só uma lista de disponibilidade (quais jogos aparecem para o perfil) — não é uma configuração interna do jogo, que continua 100% automática a partir do perfil.

Cadastrar Alunos (login, senha, perfil associado) é um fluxo à parte, independente da configuração de perfis:

Dashboard

↓

Gerenciar Alunos

↓

Cadastrar/Editar Aluno (nome, login, senha, perfil de apoio)

---

## Fluxo do Aluno

Login

↓

Autenticação

↓

Carregar Perfil

↓

Carregar Jogos Disponíveis

↓

Tutorial

↓

Gameplay

↓

Resultado

---

## Estados do Jogo

Idle

↓

Loading

↓

Tutorial

↓

Playing

↓

Paused

↓

Finished

O jogo roda isolado em um iframe. Tutorial e Playing acontecem dentro do próprio jogo (ele decide sua própria tela inicial/nível). A transição para Finished é sinalizada ao host por postMessage, que só então grava o resultado.

---

## Estados do Perfil Adaptativo

Loaded

↓

Applying Configuration

↓

Visual Configuration Applied

↓

Audio Configuration Applied

↓

Gameplay Configuration Applied

↓

Ready

---

## Exemplo Completo

Professor define:

Perfil:
TEA Nível 2

Configurações:

* Tempo ilimitado
* Sons reduzidos
* Feedback constante
* Poucos estímulos visuais

↓

Lucas realiza login

↓

Sistema identifica:

Perfil:
TEA Nível 2

↓

FGI carrega automaticamente:

* Configuração visual
* Configuração auditiva
* Configuração cognitiva

↓

Jogo inicia adaptado ao aluno

↓

Resultado é exibido

---

## Princípio Arquitetural

Configurações pertencem ao perfil.

Perfis pertencem aos alunos.

Jogos pertencem ao FGI.

Resultados pertencem ao histórico do aluno.
