# Integração — Envio dos Resultados para a Plataforma Educandus

Documento de análise e **proposta** de integração para enviar os resultados das
atividades do FGI a uma plataforma externa. **Status: aguardando aprovação —
nada foi implementado ainda.**

- **Destino definido:** plataforma própria da Educandus (não é LMS de mercado, não
  usa xAPI/SCORM/LTI — o contrato é nosso).
- **Modo definido:** automático, **1 objeto por execução** (uma jogada = um envio).
- **Problema a resolver:** hoje o resultado só existe no `localStorage` do
  navegador e a visualização despeja o **array inteiro** de uma vez ("vários JSON").

---

## 1. Como o JSON chega ao professor hoje

Nada trafega pela rede. O app é 100% client-side e usa o `localStorage` do
navegador como banco compartilhado entre aluno e professor — **os dois só se
enxergam se estiverem no mesmo navegador/dispositivo.**

```
Jogo (iframe)          Host do jogo           Armazenamento          Professor
soma / subtracao       student/game.js        storage-service.js     teacher/reports.js
────────────────       ────────────────       ─────────────────      ──────────────────
JOGO_CONCLUIDO ──────▶ session.finish() ────▶ addGameResult() ─────▶ getGameResults()
(postMessage)          (monta o objeto)        localStorage            JSON.stringify(array)
                                               'fgi:resultados'        (botão "Ver JSON")
```

| Etapa | Arquivo | Papel |
| --- | --- | --- |
| 1. Fim do jogo | [`games/soma/script.js`](../FGI/games/soma/script.js#L505-L513) | `postMessage({ type:'JOGO_CONCLUIDO', ... })` — uma vez |
| 2. Recebe e calcula | [`shared/js/student/game.js`](../FGI/shared/js/student/game.js#L47-L64) | Listener se remove após a 1ª mensagem; chama `finish()` |
| 3. Monta o objeto | [`shared/js/fgi-engine.js`](../FGI/shared/js/fgi-engine.js#L130-L145) | Adiciona aluno, jogo, tempo, data |
| 4. Grava | [`shared/js/storage-service.js`](../FGI/shared/js/storage-service.js#L198-L204) | `addGameResult()` → `localStorage` |
| 5. Professor lê | [`shared/js/teacher/reports.js`](../FGI/shared/js/teacher/reports.js#L30-L32) | Despeja o array inteiro do aluno |

---

## 2. Estrutura do JSON de um resultado

Cada execução grava **um** objeto assim (chave `fgi:resultados`):

```json
{
  "id": "res_lz4k2_a1b2c3",
  "alunoId": "std_lucas",
  "nomeAluno": "Lucas",
  "jogoId": "soma",
  "nivelDeApoio": "tea_2",
  "tempoSegundos": 42,
  "concluidoEm": "2026-07-21T13:05:00.000Z",
  "pontuacao": 80,
  "escore": { "atual": 80, "minima": 0, "maxima": 100 },
  "tentativas": 5,
  "sucesso": false,
  "detalhes": "Acertos: 4 de 5 (nível 2)"
}
```

O formato já é limpo e serializável — não precisa de transformação para sair do
navegador. O bloco `escore` é auto-descritivo: informa o valor **atual** e a
escala (**mínima**/**máxima**, sempre 0–100 por ser % de acerto), para a
plataforma não precisar assumir a escala. O `pontuacao` cru é mantido para
compatibilidade com o gamification interno.

---

## 3. Diagnóstico do "vários JSON"

**Não há bug de duplicação.** Cada execução grava exatamente 1 objeto: o
`postMessage` é emitido uma vez, o listener se remove após a primeira mensagem e
navega para `result.html`, então cada visita a `game.html` produz um único
resultado.

O "vários JSON" vem de **como o professor visualiza**: o relatório mostra o
**array acumulado** de todas as execuções do aluno de uma só vez —

```js
// teacher/reports.js:32
const jsonDump = JSON.stringify(studentResults, null, 2); // array com N objetos
```

Isso gera dois problemas para a integração:

1. **Visualização** = um blob crescente, em vez de eventos individuais.
2. **Risco de reenvio:** se a integração for feita "lendo `fgi:resultados` e
   mandando tudo", a cada nova jogada reenvia-se o histórico inteiro → a
   plataforma recebe **duplicatas**. É o anti-padrão a evitar.

> **Correção adotada na proposta:** emitir **1 evento no momento de cada
> execução**, num **ponto único** — `addGameResult()`. É o único lugar por onde
> toda jogada passa exatamente uma vez.

---

## 4. Arquitetura proposta

Como a plataforma é própria, usamos um **POST REST simples**, 1 objeto por
execução, com **fila de reenvio (outbox)** para offline e **idempotência por
`id`** para nunca duplicar.

```
addGameResult(entry)               EducandusSync                Plataforma Educandus
──────────────────────             ──────────────              ─────────────────────
grava local (enviado:false) ─────▶ POST 1 objeto ────────────▶ upsert por resultado.id
                                       │  sucesso                (idempotente)
                                       └─ marca enviado:true

sincronizarPendentes()  ──────────▶ reenvia SÓ os enviado:false (retry / offline)
```

### 4.1. Payload — 1 objeto por execução

Envelope estável reaproveitando o objeto atual. O `resultado.id` é a **chave de
idempotência**: o servidor faz *upsert* por `id`, então retries não duplicam.

```json
{
  "evento": "atividade_concluida",
  "versaoApp": "FGI-1.0",
  "resultado": {
    "id": "res_lz4k2_a1b2c3",
    "alunoId": "std_lucas", "nomeAluno": "Lucas",
    "jogoId": "soma", "nivelDeApoio": "tea_2",
    "pontuacao": 80, "escore": { "atual": 80, "minima": 0, "maxima": 100 },
    "tentativas": 5, "sucesso": false,
    "tempoSegundos": 42, "detalhes": "Acertos: 4 de 5 (nível 2)",
    "concluidoEm": "2026-07-21T13:05:00.000Z"
  }
}
```

### 4.2. Ponto único de emissão

Alteração mínima em [`storage-service.js`](../FGI/shared/js/storage-service.js#L198-L204):

```js
addGameResult(result) {
  const resultados = this.getGameResults();
  const entry = Object.assign({ id: generateId('res'), enviado: false }, result);
  resultados.push(entry);
  writeJSON(KEYS.resultados, resultados);
  EducandusSync.enviar(entry);   // dispara 1 POST — aqui e em nenhum outro lugar
  return entry;
}
```

### 4.3. Módulo novo `shared/js/educandus-sync.js` (esboço)

```js
(function (global) {
  const ENDPOINT = () => (StorageService.getSettings().integracao || {}).endpoint;
  const TOKEN    = () => (StorageService.getSettings().integracao || {}).token;

  function montarPayload(entry) {
    const { enviado, ...resultado } = entry;     // `enviado` é controle interno, não vai à API
    return { evento: 'atividade_concluida', versaoApp: 'FGI-1.0', resultado };
  }

  async function postar(entry) {
    const url = ENDPOINT();
    if (!url) return false;                      // integração não configurada → mantém local
    try {
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json',
                   'Authorization': 'Bearer ' + (TOKEN() || '') },
        body: JSON.stringify(montarPayload(entry)),
      });
      return resp.ok;
    } catch (e) { return false; }                // rede caiu → fica pendente
  }

  function marcarEnviado(id) {
    const todos = StorageService.getGameResults();
    const r = todos.find((x) => x.id === id);
    if (r) { r.enviado = true; localStorage.setItem('fgi:resultados', JSON.stringify(todos)); }
  }

  async function enviar(entry) {                 // chamado a cada execução
    if (await postar(entry)) marcarEnviado(entry.id);
  }

  async function sincronizarPendentes() {        // varredor: só os que faltam, nunca tudo
    for (const r of StorageService.getGameResults().filter((x) => !x.enviado)) {
      if (await postar(r)) marcarEnviado(r.id);
    }
  }

  global.EducandusSync = { enviar, sincronizarPendentes };
})(window);
```

O varredor (`sincronizarPendentes`) pode rodar ao abrir as telas do professor
e/ou por `setInterval`, com um botão "Reenviar pendentes" nos relatórios.

---

## 5. O que a plataforma Educandus precisa fornecer

| Item | Necessário para |
| --- | --- |
| **URL do endpoint** (ex.: `POST /api/fgi/resultados`) | Destino do POST — guardado em `configGeral.integracao.endpoint` |
| **Autenticação** (token Bearer / API key) | Header `Authorization` |
| **CORS** habilitado para a origem do FGI | Sem isso o navegador bloqueia o `fetch` |
| **Upsert por `resultado.id`** | Idempotência (retry seguro, zero duplicata) |

---

## 6. Plano de implementação (quando aprovado)

| # | Ação | Arquivo |
| --- | --- | --- |
| 1 | Criar o módulo de sincronização | `shared/js/educandus-sync.js` (novo) |
| 2 | Adicionar `enviado: false` e a chamada `EducandusSync.enviar()` | [`shared/js/storage-service.js`](../FGI/shared/js/storage-service.js) |
| 3 | Incluir `<script src="../shared/js/educandus-sync.js">` nas páginas | HTMLs de `student/` e `teacher/` |
| 4 | Campo de endpoint/token na tela de configurações | [`shared/js/teacher/settings.js`](../FGI/shared/js/teacher/settings.js) |
| 5 | (Opcional) Botão "Reenviar pendentes" + coluna de status | [`shared/js/teacher/reports.js`](../FGI/shared/js/teacher/reports.js) |

**Compatibilidade:** sem endpoint configurado, `enviar()` não faz nada e o app
continua funcionando 100% offline como hoje — a integração é aditiva.

---

## 7. Alternativas descartadas

| Opção | Por que não (neste caso) |
| --- | --- |
| **xAPI / LRS** | Padrão de LMS; desnecessário quando o destino é uma API própria |
| **SCORM** | Exigiria empacotar o jogo e rodá-lo *dentro* do LMS |
| **LTI** | Serve para *lançar* o FGI a partir de um LMS, não é o caso |
| **Exportar arquivo (.json/.csv)** | É manual; o requisito é envio automático |

---

## 8. Resumo

- **Hoje:** resultado só no `localStorage`; professor vê o array acumulado ("vários JSON").
- **Proposta:** **1 POST por execução** a partir de `addGameResult()`, com envelope
  estável, fila de reenvio e idempotência por `id` — troca "despejo do array" por
  "eventos individuais".
- **Pendências para implementar:** URL do endpoint, autenticação e CORS do lado da
  Educandus.
