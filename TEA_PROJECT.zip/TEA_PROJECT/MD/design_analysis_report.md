# Relatório de Análise de Design e Layout — FGI Learning Platform

Este relatório apresenta sugestões visuais e estruturais para elevar a qualidade estética e a usabilidade da plataforma FGI, adaptando-a de forma profissional e acessível para alunos neurodivergentes e professores.

---

## 1. Mockup Proposto: Jogo da Subtração

Esta proposta substitui o layout atual por uma interface com cantos arredondados, fontes orgânicas adequadas para o público infantil com TEA e um mascote amigável em vetor no lugar de emojis.

![Mockup do Novo Design do Jogo da Subtração](C:/Users/ricoa/.gemini/antigravity-ide/brain/42c31ddb-1253-4a49-adcf-a9e6f9a14f2f/subtraction_game_ui_mockup_1784317939226.png)

### Principais Melhorias Aplicadas
*   **Tipografia Acessível**: Uso de fontes arredondadas e espessas, que facilitam a leitura e diminuem o estresse cognitivo.
*   **Mascote Expressivo**: A coruja foi redesenhada de forma vetorizada e integrada organicamente ao fluxo da tela, ajudando na conexão afetiva do aluno com o jogo.
*   **Fichas Físicas Virtuais**: As opções de resposta possuem sombras projetadas que se assemelham a blocos de encaixe táteis.
*   **Área de Resposta Tridimensional**: O espaço do resultado foi desenhado como uma cavidade de encaixe com marcação tracejada clara, dando um senso físico ao arrastar e soltar.

---

## 2. Mockups Propostos para o Painel do Aluno

Disponibilizamos três caminhos visuais para o portal do aluno, focados em clareza, acessibilidade cognitiva e excelência em UX/UI.

### 2.1. Opção A: Design Orgânico (Tema Azul)
Esta opção mantém o menu lateral azul e a navegação em formato de carrossel de jogos, com um fundo sólido limpo em azul-gelo.

![Mockup do Painel do Aluno - Tema Azul](C:/Users/ricoa/.gemini/antigravity-ide/brain/42c31ddb-1253-4a49-adcf-a9e6f9a14f2f/student_portal_clean_bg_mockup_1784318341539.png)

*   **Destaques**: Menu lateral com cantos curvos e avatar de coala; carrossel de jogos horizontal; botões azuis arredondados em formato de pílula.

### 2.2. Opção B: Design de Grade Acolhedor (Tema Creme Quente)
Esta opção introduz um layout de grade (grid) mais aberto, com o menu de navegação e as informações do aluno consolidados no cabeçalho superior (topo), adotando um tema de tons creme e pêssego/laranja pastel.

![Mockup do Painel do Aluno - Tema Creme](C:/Users/ricoa/.gemini/antigravity-ide/brain/42c31ddb-1253-4a49-adcf-a9e6f9a14f2f/student_portal_warm_grid_mockup_1784318459475.png)

*   **Destaques**: Cabeçalho no topo com avatar de panda; os jogos são organizados em uma grade de cards maiores e mais visíveis; tons creme de baixa luminosidade que evitam reflexos fortes na tela.

### 2.3. Opção C: Design Premium Minimalista (Tema Menta & Glassmorphic)
Criado com as melhores práticas de UX/UI moderno e focado em acessibilidade cognitiva avançada, esta opção utiliza tons de menta e teal suaves, um cabeçalho flutuante translúcido (efeito vidro) e cartões de jogos sofisticados com sombras sutis tridimensionais.

![Mockup do Painel do Aluno - Tema Premium](C:/Users/ricoa/.gemini/antigravity-ide/brain/42c31ddb-1253-4a49-adcf-a9e6f9a14f2f/student_portal_premium_ux_mockup_1784318595409.png)

*   **Destaques**: Fundo menta-pastel calmo que acalma a vista; cabeçalho flutuante no topo com avatar vetorizado de panda-vermelho; cards de jogo altamente definidos lado a lado; controle de progresso horizontal com estrelas flutuantes de brilho suave; visual clean, premium e livre de ruídos.

---

## 3. Mockup Proposto: Painel do Professor

Esta proposta moderniza a área administrativa, transformando um painel centrado em formulários e dados brutos em uma interface SaaS elegante, focada em cartões e gráficos visuais claros.

![Mockup do Novo Design do Painel do Professor](C:/Users/ricoa/.gemini/antigravity-ide/brain/42c31ddb-1253-4a49-adcf-a9e6f9a14f2f/teacher_dashboard_ui_mockup_1784317950454.png)

### Principais Melhorias Aplicadas
*   **Remoção de JSON Bruto**: Toda a configuração do banco de dados e perfis é traduzida em caixas interativas, seletores elegantes e cartões informativos visuais.
*   **Estatísticas Visuais**: Gráficos de rosca e barras de progresso ajudam o educador a acompanhar a evolução dos alunos de forma rápida e clara.
*   **Paleta de Cores Refinada**: Slate gray, tons de azul e verde pastéis corporativos passam credibilidade e sofisticação.
*   **Organização e Foco**: A barra lateral de navegação limpa substitui menus dispersos, maximizando o espaço de trabalho.

---

## 4. Diretrizes de Implementação Sugeridas

> [!TIP]
> **Consistência de Componentes**: Utilizar variáveis CSS unificadas (`base.css`) para gerenciar as bordas arredondadas (`border-radius: 16px` para crianças e `8px` para professores) e as sombras das caixas, garantindo consistência por toda a plataforma.

> [!IMPORTANT]
> **Acessibilidade WCAG**: Manter um contraste mínimo de `4.5:1` para todos os textos de instruções e leituras nos dois portais, especialmente nos temas adaptados para TEA (que usam tons pastéis de lavanda e verde).
