# 01_ARCHITECTURE.md

# Arquitetura Inicial do FGI

FGI/

teacher/

student/

games/

profiles/

shared/

docs/

---

## teacher/

Responsável pela área do professor.

teacher/

dashboard.html

profiles.html

students.html

games.html

reports.html

settings.html

O professor não configura alunos individualmente (não existe ajuste adaptativo por aluno), mas precisa cadastrar quem são os alunos e qual perfil cada um usa. Esse cadastro (login, senha, perfil associado) é feito em students.html.

games.html não configura o jogo em si — é apenas uma lista de quais jogos ficam disponíveis para o perfil selecionado. A adaptação do jogo continua automática, vinda do perfil.

settings.html ajusta parâmetros globais de um perfil (ex.: forçar mudo, reduzir estímulos), sobrepondo o JSON base do perfil.

---

## student/

Responsável pela área do aluno.

student/

login.html

home.html

activities.html

game.html

result.html

---

## games/

Jogos independentes e reutilizáveis.

games/

soma/

Cada pasta é nomeada pelo próprio jogo (não por número genérico), já que cada jogo tem identidade própria (ex.: soma/, e futuramente outros como subtracao/).

Cada jogo deve funcionar isoladamente.

Os jogos recebem apenas configurações e retornam apenas resultados.

Contrato técnico: cada jogo roda em um iframe (index.html, script.js, style.css, manifest.json). O host injeta as configurações do perfil ativo via querystring (?config=<configuracoes em JSON>) e o jogo devolve o resultado via window.parent.postMessage({ type: "GAME_FINISHED", ... }). O jogo nunca acessa localStorage nem os dados do aluno/professor diretamente.

---

## profiles/

Contém os perfis de apoio utilizados pelo sistema.

profiles/

tipico.json

tea_1.json

tea_2.json

tea_3.json

tdah.json

dislexia.json

Discalculia e Deficiência Intelectual foram removidos do protótipo por agora (podem voltar depois).

Cada arquivo segue o mesmo esquema: configuracoes.visual, configuracoes.audio, configuracoes.cognitivo.

---

## shared/

Arquivos compartilhados entre todos os módulos.

shared/

css/

js/

assets/

components/

icons/

---

## Regras Arquiteturais

O professor não conhece os jogos internamente.

Os jogos não conhecem o professor.

Os jogos não conhecem os alunos.

Os jogos recebem apenas configurações adaptativas.

Os jogos retornam apenas resultados da atividade.

Os jogos rodam isolados em iframe, nunca compartilhando escopo/JS com o host.

---

## Exemplo de fluxo

Professor

↓

Configura perfil TEA Nível 2

↓

Aluno Lucas realiza login

↓

Sistema identifica perfil TEA Nível 2

↓

FGI aplica adaptações automaticamente

↓

Jogo é executado

↓

Resultado é apresentado
